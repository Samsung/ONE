# Ruy documentation

This directory will eventually contain ruy documentation.
