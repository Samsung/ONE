## Introduction

These are some examples about how to use RUY.

## BUILD

Build the example with bazel commands:
```
bazel build //ruy/example:example
```
You can find the generated target under directory:
```
./bazel-bin/ruy/example
```
