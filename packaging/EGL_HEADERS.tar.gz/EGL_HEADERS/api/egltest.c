/*
 * Copyright 2013-2020 The Khronos Group Inc.
 * SPDX-License-Identifier: Apache-2.0
 */

/* Simple test that generated EGL headers compile with C and C++ */
#include "EGL/egl.h"
#include "EGL/eglext.h"
