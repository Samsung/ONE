// clang-format off
// Generated file (from: reduce_max_float_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max_float_2_nnfw {
// Generated reduce_max_float_2_nnfw test
#include "generated/examples/reduce_max_float_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max_float_2_nnfw.model.cpp"
} // namespace reduce_max_float_2_nnfw

TEST_F(GeneratedTests, reduce_max_float_2_nnfw) {
    execute(reduce_max_float_2_nnfw::CreateModel,
            reduce_max_float_2_nnfw::is_ignored,
            reduce_max_float_2_nnfw::get_examples());
}

