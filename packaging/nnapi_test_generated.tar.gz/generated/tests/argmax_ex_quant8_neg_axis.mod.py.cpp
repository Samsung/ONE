// clang-format off
// Generated file (from: argmax_ex_quant8_neg_axis.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_ex_quant8_neg_axis {
// Generated argmax_ex_quant8_neg_axis test
#include "generated/examples/argmax_ex_quant8_neg_axis.example.cpp"
// Generated model constructor
#include "generated/models/argmax_ex_quant8_neg_axis.model.cpp"
} // namespace argmax_ex_quant8_neg_axis

TEST_F(GeneratedTests, argmax_ex_quant8_neg_axis) {
    execute(argmax_ex_quant8_neg_axis::CreateModel,
            argmax_ex_quant8_neg_axis::is_ignored,
            argmax_ex_quant8_neg_axis::get_examples());
}

