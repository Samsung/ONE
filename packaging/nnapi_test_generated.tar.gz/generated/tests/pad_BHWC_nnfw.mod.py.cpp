// clang-format off
// Generated file (from: pad_BHWC_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_BHWC_nnfw {
// Generated pad_BHWC_nnfw test
#include "generated/examples/pad_BHWC_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_BHWC_nnfw.model.cpp"
} // namespace pad_BHWC_nnfw

TEST_F(GeneratedTests, pad_BHWC_nnfw) {
    execute(pad_BHWC_nnfw::CreateModel,
            pad_BHWC_nnfw::is_ignored,
            pad_BHWC_nnfw::get_examples());
}

