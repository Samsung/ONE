// clang-format off
// Generated file (from: pack_ex_2D_int_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pack_ex_2D_int_2 {
// Generated pack_ex_2D_int_2 test
#include "generated/examples/pack_ex_2D_int_2.example.cpp"
// Generated model constructor
#include "generated/models/pack_ex_2D_int_2.model.cpp"
} // namespace pack_ex_2D_int_2

TEST_F(GeneratedTests, pack_ex_2D_int_2) {
    execute(pack_ex_2D_int_2::CreateModel,
            pack_ex_2D_int_2::is_ignored,
            pack_ex_2D_int_2::get_examples());
}

