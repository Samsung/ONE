// clang-format off
// Generated file (from: floor_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace floor_ {
// Generated floor_ test
#include "generated/examples/floor_.example.cpp"
// Generated model constructor
#include "generated/models/floor_.model.cpp"
} // namespace floor_

TEST_F(GeneratedTests, floor_) {
    execute(floor_::CreateModel,
            floor_::is_ignored,
            floor_::get_examples());
}

