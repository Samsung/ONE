// clang-format off
// Generated file (from: tanh_v1_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace tanh_v1_2 {
// Generated tanh_v1_2 test
#include "generated/examples/tanh_v1_2.example.cpp"
// Generated model constructor
#include "generated/models/tanh_v1_2.model.cpp"
} // namespace tanh_v1_2

TEST_F(GeneratedTests, tanh_v1_2) {
    execute(tanh_v1_2::CreateModel,
            tanh_v1_2::is_ignored,
            tanh_v1_2::get_examples());
}

TEST_F(GeneratedTests, tanh_v1_2_2) {
    execute(tanh_v1_2::CreateModel_2,
            tanh_v1_2::is_ignored_2,
            tanh_v1_2::get_examples_2());
}

TEST_F(GeneratedTests, tanh_v1_2_zero_sized) {
    execute(tanh_v1_2::CreateModel_zero_sized,
            tanh_v1_2::is_ignored_zero_sized,
            tanh_v1_2::get_examples_zero_sized());
}

TEST_F(GeneratedTests, tanh_v1_2_zero_sized_quant8) {
    execute(tanh_v1_2::CreateModel_zero_sized_quant8,
            tanh_v1_2::is_ignored_zero_sized_quant8,
            tanh_v1_2::get_examples_zero_sized_quant8());
}

