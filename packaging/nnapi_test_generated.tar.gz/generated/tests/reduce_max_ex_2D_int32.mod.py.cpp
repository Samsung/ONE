// clang-format off
// Generated file (from: reduce_max_ex_2D_int32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max_ex_2D_int32 {
// Generated reduce_max_ex_2D_int32 test
#include "generated/examples/reduce_max_ex_2D_int32.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max_ex_2D_int32.model.cpp"
} // namespace reduce_max_ex_2D_int32

TEST_F(GeneratedTests, reduce_max_ex_2D_int32) {
    execute(reduce_max_ex_2D_int32::CreateModel,
            reduce_max_ex_2D_int32::is_ignored,
            reduce_max_ex_2D_int32::get_examples());
}

