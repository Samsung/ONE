// clang-format off
// Generated file (from: neg_ex_3D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace neg_ex_3D_float {
// Generated neg_ex_3D_float test
#include "generated/examples/neg_ex_3D_float.example.cpp"
// Generated model constructor
#include "generated/models/neg_ex_3D_float.model.cpp"
} // namespace neg_ex_3D_float

TEST_F(GeneratedTests, neg_ex_3D_float) {
    execute(neg_ex_3D_float::CreateModel,
            neg_ex_3D_float::is_ignored,
            neg_ex_3D_float::get_examples());
}

