// clang-format off
// Generated file (from: add_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace add_dynamic_nnfw {
// Generated add_dynamic_nnfw test
#include "generated/examples/add_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/add_dynamic_nnfw.model.cpp"
} // namespace add_dynamic_nnfw

TEST_F(GeneratedTests, add_dynamic_nnfw) {
    execute(add_dynamic_nnfw::CreateModel,
            add_dynamic_nnfw::is_ignored,
            add_dynamic_nnfw::get_examples());
}

