// clang-format off
// Generated file (from: abs_2D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace abs_2D_float_nnfw {
// Generated abs_2D_float_nnfw test
#include "generated/examples/abs_2D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/abs_2D_float_nnfw.model.cpp"
} // namespace abs_2D_float_nnfw

TEST_F(GeneratedTests, abs_2D_float_nnfw) {
    execute(abs_2D_float_nnfw::CreateModel,
            abs_2D_float_nnfw::is_ignored,
            abs_2D_float_nnfw::get_examples());
}

