// clang-format off
// Generated file (from: range_ex_float_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace range_ex_float_2 {
// Generated range_ex_float_2 test
#include "generated/examples/range_ex_float_2.example.cpp"
// Generated model constructor
#include "generated/models/range_ex_float_2.model.cpp"
} // namespace range_ex_float_2

TEST_F(GeneratedTests, range_ex_float_2) {
    execute(range_ex_float_2::CreateModel,
            range_ex_float_2::is_ignored,
            range_ex_float_2::get_examples());
}

