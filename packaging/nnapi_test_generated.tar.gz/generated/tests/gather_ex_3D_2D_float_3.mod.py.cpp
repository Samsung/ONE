// clang-format off
// Generated file (from: gather_ex_3D_2D_float_3.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_ex_3D_2D_float_3 {
// Generated gather_ex_3D_2D_float_3 test
#include "generated/examples/gather_ex_3D_2D_float_3.example.cpp"
// Generated model constructor
#include "generated/models/gather_ex_3D_2D_float_3.model.cpp"
} // namespace gather_ex_3D_2D_float_3

TEST_F(GeneratedTests, gather_ex_3D_2D_float_3) {
    execute(gather_ex_3D_2D_float_3::CreateModel,
            gather_ex_3D_2D_float_3::is_ignored,
            gather_ex_3D_2D_float_3::get_examples());
}

