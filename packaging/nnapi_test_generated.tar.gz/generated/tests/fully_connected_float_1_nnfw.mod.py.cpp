// clang-format off
// Generated file (from: fully_connected_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace fully_connected_float_1_nnfw {
// Generated fully_connected_float_1_nnfw test
#include "generated/examples/fully_connected_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/fully_connected_float_1_nnfw.model.cpp"
} // namespace fully_connected_float_1_nnfw

TEST_F(GeneratedTests, fully_connected_float_1_nnfw) {
    execute(fully_connected_float_1_nnfw::CreateModel,
            fully_connected_float_1_nnfw::is_ignored,
            fully_connected_float_1_nnfw::get_examples());
}

