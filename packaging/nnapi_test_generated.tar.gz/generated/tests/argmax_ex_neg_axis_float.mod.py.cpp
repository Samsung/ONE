// clang-format off
// Generated file (from: argmax_ex_neg_axis_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_ex_neg_axis_float {
// Generated argmax_ex_neg_axis_float test
#include "generated/examples/argmax_ex_neg_axis_float.example.cpp"
// Generated model constructor
#include "generated/models/argmax_ex_neg_axis_float.model.cpp"
} // namespace argmax_ex_neg_axis_float

TEST_F(GeneratedTests, argmax_ex_neg_axis_float) {
    execute(argmax_ex_neg_axis_float::CreateModel,
            argmax_ex_neg_axis_float::is_ignored,
            argmax_ex_neg_axis_float::get_examples());
}

