// clang-format off
// Generated file (from: prelu_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace prelu_float_1_nnfw {
// Generated prelu_float_1_nnfw test
#include "generated/examples/prelu_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/prelu_float_1_nnfw.model.cpp"
} // namespace prelu_float_1_nnfw

TEST_F(GeneratedTests, prelu_float_1_nnfw) {
    execute(prelu_float_1_nnfw::CreateModel,
            prelu_float_1_nnfw::is_ignored,
            prelu_float_1_nnfw::get_examples());
}

