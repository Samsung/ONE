// clang-format off
// Generated file (from: argmax_ex_int32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_ex_int32 {
// Generated argmax_ex_int32 test
#include "generated/examples/argmax_ex_int32.example.cpp"
// Generated model constructor
#include "generated/models/argmax_ex_int32.model.cpp"
} // namespace argmax_ex_int32

TEST_F(GeneratedTests, argmax_ex_int32) {
    execute(argmax_ex_int32::CreateModel,
            argmax_ex_int32::is_ignored,
            argmax_ex_int32::get_examples());
}

