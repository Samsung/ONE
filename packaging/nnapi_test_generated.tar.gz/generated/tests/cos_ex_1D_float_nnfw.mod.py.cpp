// clang-format off
// Generated file (from: cos_ex_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace cos_ex_1D_float_nnfw {
// Generated cos_ex_1D_float_nnfw test
#include "generated/examples/cos_ex_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/cos_ex_1D_float_nnfw.model.cpp"
} // namespace cos_ex_1D_float_nnfw

TEST_F(GeneratedTests, cos_ex_1D_float_nnfw) {
    execute(cos_ex_1D_float_nnfw::CreateModel,
            cos_ex_1D_float_nnfw::is_ignored,
            cos_ex_1D_float_nnfw::get_examples());
}

