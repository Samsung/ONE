// clang-format off
// Generated file (from: softmax_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace softmax_dynamic_nnfw {
// Generated softmax_dynamic_nnfw test
#include "generated/examples/softmax_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/softmax_dynamic_nnfw.model.cpp"
} // namespace softmax_dynamic_nnfw

TEST_F(GeneratedTests, softmax_dynamic_nnfw) {
    execute(softmax_dynamic_nnfw::CreateModel,
            softmax_dynamic_nnfw::is_ignored,
            softmax_dynamic_nnfw::get_examples());
}

