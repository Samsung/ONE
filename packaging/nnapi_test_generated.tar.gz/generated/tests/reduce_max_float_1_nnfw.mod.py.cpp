// clang-format off
// Generated file (from: reduce_max_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max_float_1_nnfw {
// Generated reduce_max_float_1_nnfw test
#include "generated/examples/reduce_max_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max_float_1_nnfw.model.cpp"
} // namespace reduce_max_float_1_nnfw

TEST_F(GeneratedTests, reduce_max_float_1_nnfw) {
    execute(reduce_max_float_1_nnfw::CreateModel,
            reduce_max_float_1_nnfw::is_ignored,
            reduce_max_float_1_nnfw::get_examples());
}

