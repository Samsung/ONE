// clang-format off
// Generated file (from: hashtable_lookup_float_4D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace hashtable_lookup_float_4D_nnfw {
// Generated hashtable_lookup_float_4D_nnfw test
#include "generated/examples/hashtable_lookup_float_4D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/hashtable_lookup_float_4D_nnfw.model.cpp"
} // namespace hashtable_lookup_float_4D_nnfw

TEST_F(GeneratedTests, hashtable_lookup_float_4D_nnfw) {
    execute(hashtable_lookup_float_4D_nnfw::CreateModel,
            hashtable_lookup_float_4D_nnfw::is_ignored,
            hashtable_lookup_float_4D_nnfw::get_examples());
}

