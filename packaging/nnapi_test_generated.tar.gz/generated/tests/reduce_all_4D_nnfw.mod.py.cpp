// clang-format off
// Generated file (from: reduce_all_4D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_all_4D_nnfw {
// Generated reduce_all_4D_nnfw test
#include "generated/examples/reduce_all_4D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_all_4D_nnfw.model.cpp"
} // namespace reduce_all_4D_nnfw

TEST_F(GeneratedTests, reduce_all_4D_nnfw) {
    execute(reduce_all_4D_nnfw::CreateModel,
            reduce_all_4D_nnfw::is_ignored,
            reduce_all_4D_nnfw::get_examples());
}

