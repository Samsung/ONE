// clang-format off
// Generated file (from: cast_ex_int32_to_float32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace cast_ex_int32_to_float32 {
// Generated cast_ex_int32_to_float32 test
#include "generated/examples/cast_ex_int32_to_float32.example.cpp"
// Generated model constructor
#include "generated/models/cast_ex_int32_to_float32.model.cpp"
} // namespace cast_ex_int32_to_float32

TEST_F(GeneratedTests, cast_ex_int32_to_float32) {
    execute(cast_ex_int32_to_float32::CreateModel,
            cast_ex_int32_to_float32::is_ignored,
            cast_ex_int32_to_float32::get_examples());
}

