// clang-format off
// Generated file (from: reduce_max_ex_float_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max_ex_float_2 {
// Generated reduce_max_ex_float_2 test
#include "generated/examples/reduce_max_ex_float_2.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max_ex_float_2.model.cpp"
} // namespace reduce_max_ex_float_2

TEST_F(GeneratedTests, reduce_max_ex_float_2) {
    execute(reduce_max_ex_float_2::CreateModel,
            reduce_max_ex_float_2::is_ignored,
            reduce_max_ex_float_2::get_examples());
}

