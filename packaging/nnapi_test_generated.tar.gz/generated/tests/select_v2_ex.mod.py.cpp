// clang-format off
// Generated file (from: select_v2_ex.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace select_v2_ex {
// Generated select_v2_ex test
#include "generated/examples/select_v2_ex.example.cpp"
// Generated model constructor
#include "generated/models/select_v2_ex.model.cpp"
} // namespace select_v2_ex

TEST_F(GeneratedTests, select_v2_ex_float) {
    execute(select_v2_ex::CreateModel,
            select_v2_ex::is_ignored,
            select_v2_ex::get_examples_float());
}

TEST_F(GeneratedTests, select_v2_ex_broadcast_1d_single_value) {
    execute(select_v2_ex::CreateModel_2,
            select_v2_ex::is_ignored_2,
            select_v2_ex::get_examples_broadcast_1d_single_value());
}

TEST_F(GeneratedTests, select_v2_ex_broadcast_less_4d) {
    execute(select_v2_ex::CreateModel_3,
            select_v2_ex::is_ignored_3,
            select_v2_ex::get_examples_broadcast_less_4d());
}

TEST_F(GeneratedTests, select_v2_ex_broadcast_2d_one) {
    execute(select_v2_ex::CreateModel_4,
            select_v2_ex::is_ignored_4,
            select_v2_ex::get_examples_broadcast_2d_one());
}

