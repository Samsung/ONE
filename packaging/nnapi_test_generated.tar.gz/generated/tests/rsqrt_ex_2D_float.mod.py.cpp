// clang-format off
// Generated file (from: rsqrt_ex_2D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace rsqrt_ex_2D_float {
// Generated rsqrt_ex_2D_float test
#include "generated/examples/rsqrt_ex_2D_float.example.cpp"
// Generated model constructor
#include "generated/models/rsqrt_ex_2D_float.model.cpp"
} // namespace rsqrt_ex_2D_float

TEST_F(GeneratedTests, rsqrt_ex_2D_float) {
    execute(rsqrt_ex_2D_float::CreateModel,
            rsqrt_ex_2D_float::is_ignored,
            rsqrt_ex_2D_float::get_examples());
}

