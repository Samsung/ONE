// clang-format off
// Generated file (from: log_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace log_4D_float_nnfw {
// Generated log_4D_float_nnfw test
#include "generated/examples/log_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/log_4D_float_nnfw.model.cpp"
} // namespace log_4D_float_nnfw

TEST_F(GeneratedTests, log_4D_float_nnfw) {
    execute(log_4D_float_nnfw::CreateModel,
            log_4D_float_nnfw::is_ignored,
            log_4D_float_nnfw::get_examples());
}

