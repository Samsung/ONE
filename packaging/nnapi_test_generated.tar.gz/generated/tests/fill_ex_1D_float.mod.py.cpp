// clang-format off
// Generated file (from: fill_ex_1D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace fill_ex_1D_float {
// Generated fill_ex_1D_float test
#include "generated/examples/fill_ex_1D_float.example.cpp"
// Generated model constructor
#include "generated/models/fill_ex_1D_float.model.cpp"
} // namespace fill_ex_1D_float

TEST_F(GeneratedTests, fill_ex_1D_float) {
    execute(fill_ex_1D_float::CreateModel,
            fill_ex_1D_float::is_ignored,
            fill_ex_1D_float::get_examples());
}

