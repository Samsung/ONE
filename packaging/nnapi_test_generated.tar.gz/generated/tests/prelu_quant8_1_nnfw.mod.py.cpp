// clang-format off
// Generated file (from: prelu_quant8_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace prelu_quant8_1_nnfw {
// Generated prelu_quant8_1_nnfw test
#include "generated/examples/prelu_quant8_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/prelu_quant8_1_nnfw.model.cpp"
} // namespace prelu_quant8_1_nnfw

TEST_F(GeneratedTests, prelu_quant8_1_nnfw) {
    execute(prelu_quant8_1_nnfw::CreateModel,
            prelu_quant8_1_nnfw::is_ignored,
            prelu_quant8_1_nnfw::get_examples());
}

