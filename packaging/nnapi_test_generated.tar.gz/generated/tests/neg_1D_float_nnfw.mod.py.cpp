// clang-format off
// Generated file (from: neg_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace neg_1D_float_nnfw {
// Generated neg_1D_float_nnfw test
#include "generated/examples/neg_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/neg_1D_float_nnfw.model.cpp"
} // namespace neg_1D_float_nnfw

TEST_F(GeneratedTests, neg_1D_float_nnfw) {
    execute(neg_1D_float_nnfw::CreateModel,
            neg_1D_float_nnfw::is_ignored,
            neg_1D_float_nnfw::get_examples());
}

