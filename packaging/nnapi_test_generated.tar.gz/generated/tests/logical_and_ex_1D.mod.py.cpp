// clang-format off
// Generated file (from: logical_and_ex_1D.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_and_ex_1D {
// Generated logical_and_ex_1D test
#include "generated/examples/logical_and_ex_1D.example.cpp"
// Generated model constructor
#include "generated/models/logical_and_ex_1D.model.cpp"
} // namespace logical_and_ex_1D

TEST_F(GeneratedTests, logical_and_ex_1D) {
    execute(logical_and_ex_1D::CreateModel,
            logical_and_ex_1D::is_ignored,
            logical_and_ex_1D::get_examples());
}

