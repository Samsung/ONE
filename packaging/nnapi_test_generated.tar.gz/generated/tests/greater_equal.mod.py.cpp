// clang-format off
// Generated file (from: greater_equal.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace greater_equal {
// Generated greater_equal test
#include "generated/examples/greater_equal.example.cpp"
// Generated model constructor
#include "generated/models/greater_equal.model.cpp"
} // namespace greater_equal

TEST_F(GeneratedTests, greater_equal_simple) {
    execute(greater_equal::CreateModel,
            greater_equal::is_ignored,
            greater_equal::get_examples_simple());
}

TEST_F(GeneratedTests, greater_equal_broadcast) {
    execute(greater_equal::CreateModel_2,
            greater_equal::is_ignored_2,
            greater_equal::get_examples_broadcast());
}

TEST_F(GeneratedTests, greater_equal_quantized_different_scale) {
    execute(greater_equal::CreateModel_3,
            greater_equal::is_ignored_3,
            greater_equal::get_examples_quantized_different_scale());
}

TEST_F(GeneratedTests, greater_equal_quantized_different_zero_point) {
    execute(greater_equal::CreateModel_4,
            greater_equal::is_ignored_4,
            greater_equal::get_examples_quantized_different_zero_point());
}

TEST_F(GeneratedTests, greater_equal_quantized_overflow_second_input_if_requantized) {
    execute(greater_equal::CreateModel_5,
            greater_equal::is_ignored_5,
            greater_equal::get_examples_quantized_overflow_second_input_if_requantized());
}

TEST_F(GeneratedTests, greater_equal_quantized_overflow_first_input_if_requantized) {
    execute(greater_equal::CreateModel_6,
            greater_equal::is_ignored_6,
            greater_equal::get_examples_quantized_overflow_first_input_if_requantized());
}

TEST_F(GeneratedTests, greater_equal_boolean) {
    execute(greater_equal::CreateModel_7,
            greater_equal::is_ignored_7,
            greater_equal::get_examples_boolean());
}

