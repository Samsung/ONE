// clang-format off
// Generated file (from: pack_ex_2D_float_1.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pack_ex_2D_float_1 {
// Generated pack_ex_2D_float_1 test
#include "generated/examples/pack_ex_2D_float_1.example.cpp"
// Generated model constructor
#include "generated/models/pack_ex_2D_float_1.model.cpp"
} // namespace pack_ex_2D_float_1

TEST_F(GeneratedTests, pack_ex_2D_float_1) {
    execute(pack_ex_2D_float_1::CreateModel,
            pack_ex_2D_float_1::is_ignored,
            pack_ex_2D_float_1::get_examples());
}

