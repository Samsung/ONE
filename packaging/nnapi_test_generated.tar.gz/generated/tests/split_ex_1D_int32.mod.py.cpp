// clang-format off
// Generated file (from: split_ex_1D_int32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_ex_1D_int32 {
// Generated split_ex_1D_int32 test
#include "generated/examples/split_ex_1D_int32.example.cpp"
// Generated model constructor
#include "generated/models/split_ex_1D_int32.model.cpp"
} // namespace split_ex_1D_int32

TEST_F(GeneratedTests, split_ex_1D_int32) {
    execute(split_ex_1D_int32::CreateModel,
            split_ex_1D_int32::is_ignored,
            split_ex_1D_int32::get_examples());
}

