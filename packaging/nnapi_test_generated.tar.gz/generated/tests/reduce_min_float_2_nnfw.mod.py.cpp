// clang-format off
// Generated file (from: reduce_min_float_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_min_float_2_nnfw {
// Generated reduce_min_float_2_nnfw test
#include "generated/examples/reduce_min_float_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_min_float_2_nnfw.model.cpp"
} // namespace reduce_min_float_2_nnfw

TEST_F(GeneratedTests, reduce_min_float_2_nnfw) {
    execute(reduce_min_float_2_nnfw::CreateModel,
            reduce_min_float_2_nnfw::is_ignored,
            reduce_min_float_2_nnfw::get_examples());
}

