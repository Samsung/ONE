// clang-format off
// Generated file (from: notequal_ex_broadcast_4D_2D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace notequal_ex_broadcast_4D_2D_float {
// Generated notequal_ex_broadcast_4D_2D_float test
#include "generated/examples/notequal_ex_broadcast_4D_2D_float.example.cpp"
// Generated model constructor
#include "generated/models/notequal_ex_broadcast_4D_2D_float.model.cpp"
} // namespace notequal_ex_broadcast_4D_2D_float

TEST_F(GeneratedTests, notequal_ex_broadcast_4D_2D_float) {
    execute(notequal_ex_broadcast_4D_2D_float::CreateModel,
            notequal_ex_broadcast_4D_2D_float::is_ignored,
            notequal_ex_broadcast_4D_2D_float::get_examples());
}

