// clang-format off
// Generated file (from: not_equal.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace not_equal {
// Generated not_equal test
#include "generated/examples/not_equal.example.cpp"
// Generated model constructor
#include "generated/models/not_equal.model.cpp"
} // namespace not_equal

TEST_F(GeneratedTests, not_equal_simple) {
    execute(not_equal::CreateModel,
            not_equal::is_ignored,
            not_equal::get_examples_simple());
}

TEST_F(GeneratedTests, not_equal_broadcast) {
    execute(not_equal::CreateModel_2,
            not_equal::is_ignored_2,
            not_equal::get_examples_broadcast());
}

TEST_F(GeneratedTests, not_equal_quantized_different_scale) {
    execute(not_equal::CreateModel_3,
            not_equal::is_ignored_3,
            not_equal::get_examples_quantized_different_scale());
}

TEST_F(GeneratedTests, not_equal_quantized_different_zero_point) {
    execute(not_equal::CreateModel_4,
            not_equal::is_ignored_4,
            not_equal::get_examples_quantized_different_zero_point());
}

TEST_F(GeneratedTests, not_equal_quantized_overflow_second_input_if_requantized) {
    execute(not_equal::CreateModel_5,
            not_equal::is_ignored_5,
            not_equal::get_examples_quantized_overflow_second_input_if_requantized());
}

TEST_F(GeneratedTests, not_equal_quantized_overflow_first_input_if_requantized) {
    execute(not_equal::CreateModel_6,
            not_equal::is_ignored_6,
            not_equal::get_examples_quantized_overflow_first_input_if_requantized());
}

TEST_F(GeneratedTests, not_equal_boolean) {
    execute(not_equal::CreateModel_7,
            not_equal::is_ignored_7,
            not_equal::get_examples_boolean());
}

