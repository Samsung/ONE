// clang-format off
// Generated file (from: topk_v2_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace topk_v2_1D_float_nnfw {
// Generated topk_v2_1D_float_nnfw test
#include "generated/examples/topk_v2_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/topk_v2_1D_float_nnfw.model.cpp"
} // namespace topk_v2_1D_float_nnfw

TEST_F(GeneratedTests, topk_v2_1D_float_nnfw) {
    execute(topk_v2_1D_float_nnfw::CreateModel,
            topk_v2_1D_float_nnfw::is_ignored,
            topk_v2_1D_float_nnfw::get_examples());
}

