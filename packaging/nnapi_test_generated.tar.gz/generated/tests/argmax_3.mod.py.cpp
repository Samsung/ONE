// clang-format off
// Generated file (from: argmax_3.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_3 {
// Generated argmax_3 test
#include "generated/examples/argmax_3.example.cpp"
// Generated model constructor
#include "generated/models/argmax_3.model.cpp"
} // namespace argmax_3

TEST_F(GeneratedTests, argmax_3) {
    execute(argmax_3::CreateModel,
            argmax_3::is_ignored,
            argmax_3::get_examples());
}

TEST_F(GeneratedTests, argmax_3_quant8) {
    execute(argmax_3::CreateModel_quant8,
            argmax_3::is_ignored_quant8,
            argmax_3::get_examples_quant8());
}

