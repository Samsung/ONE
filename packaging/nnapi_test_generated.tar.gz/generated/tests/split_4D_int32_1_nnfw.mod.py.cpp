// clang-format off
// Generated file (from: split_4D_int32_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_4D_int32_1_nnfw {
// Generated split_4D_int32_1_nnfw test
#include "generated/examples/split_4D_int32_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/split_4D_int32_1_nnfw.model.cpp"
} // namespace split_4D_int32_1_nnfw

TEST_F(GeneratedTests, split_4D_int32_1_nnfw) {
    execute(split_4D_int32_1_nnfw::CreateModel,
            split_4D_int32_1_nnfw::is_ignored,
            split_4D_int32_1_nnfw::get_examples());
}

