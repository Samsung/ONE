// clang-format off
// Generated file (from: transpose_conv_ex_float_4.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace transpose_conv_ex_float_4 {
// Generated transpose_conv_ex_float_4 test
#include "generated/examples/transpose_conv_ex_float_4.example.cpp"
// Generated model constructor
#include "generated/models/transpose_conv_ex_float_4.model.cpp"
} // namespace transpose_conv_ex_float_4

TEST_F(GeneratedTests, transpose_conv_ex_float_4) {
    execute(transpose_conv_ex_float_4::CreateModel,
            transpose_conv_ex_float_4::is_ignored,
            transpose_conv_ex_float_4::get_examples());
}

