// clang-format off
// Generated file (from: tanh_v1_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace tanh_v1_dynamic_nnfw {
// Generated tanh_v1_dynamic_nnfw test
#include "generated/examples/tanh_v1_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/tanh_v1_dynamic_nnfw.model.cpp"
} // namespace tanh_v1_dynamic_nnfw

TEST_F(GeneratedTests, tanh_v1_dynamic_nnfw) {
    execute(tanh_v1_dynamic_nnfw::CreateModel,
            tanh_v1_dynamic_nnfw::is_ignored,
            tanh_v1_dynamic_nnfw::get_examples());
}

