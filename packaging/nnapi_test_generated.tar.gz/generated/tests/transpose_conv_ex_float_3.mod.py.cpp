// clang-format off
// Generated file (from: transpose_conv_ex_float_3.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace transpose_conv_ex_float_3 {
// Generated transpose_conv_ex_float_3 test
#include "generated/examples/transpose_conv_ex_float_3.example.cpp"
// Generated model constructor
#include "generated/models/transpose_conv_ex_float_3.model.cpp"
} // namespace transpose_conv_ex_float_3

TEST_F(GeneratedTests, transpose_conv_ex_float_3) {
    execute(transpose_conv_ex_float_3::CreateModel,
            transpose_conv_ex_float_3::is_ignored,
            transpose_conv_ex_float_3::get_examples());
}

