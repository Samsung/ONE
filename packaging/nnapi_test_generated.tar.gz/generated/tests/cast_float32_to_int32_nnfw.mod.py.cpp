// clang-format off
// Generated file (from: cast_float32_to_int32_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace cast_float32_to_int32_nnfw {
// Generated cast_float32_to_int32_nnfw test
#include "generated/examples/cast_float32_to_int32_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/cast_float32_to_int32_nnfw.model.cpp"
} // namespace cast_float32_to_int32_nnfw

TEST_F(GeneratedTests, cast_float32_to_int32_nnfw) {
    execute(cast_float32_to_int32_nnfw::CreateModel,
            cast_float32_to_int32_nnfw::is_ignored,
            cast_float32_to_int32_nnfw::get_examples());
}

