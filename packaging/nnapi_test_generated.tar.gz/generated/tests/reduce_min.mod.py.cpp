// clang-format off
// Generated file (from: reduce_min.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_min {
// Generated reduce_min test
#include "generated/examples/reduce_min.example.cpp"
// Generated model constructor
#include "generated/models/reduce_min.model.cpp"
} // namespace reduce_min

TEST_F(GeneratedTests, reduce_min) {
    execute(reduce_min::CreateModel,
            reduce_min::is_ignored,
            reduce_min::get_examples());
}

TEST_F(GeneratedTests, reduce_min_quant8) {
    execute(reduce_min::CreateModel_quant8,
            reduce_min::is_ignored_quant8,
            reduce_min::get_examples_quant8());
}

TEST_F(GeneratedTests, reduce_min_2) {
    execute(reduce_min::CreateModel_2,
            reduce_min::is_ignored_2,
            reduce_min::get_examples_2());
}

TEST_F(GeneratedTests, reduce_min_quant8_2) {
    execute(reduce_min::CreateModel_quant8_2,
            reduce_min::is_ignored_quant8_2,
            reduce_min::get_examples_quant8_2());
}

TEST_F(GeneratedTests, reduce_min_3) {
    execute(reduce_min::CreateModel_3,
            reduce_min::is_ignored_3,
            reduce_min::get_examples_3());
}

TEST_F(GeneratedTests, reduce_min_quant8_3) {
    execute(reduce_min::CreateModel_quant8_3,
            reduce_min::is_ignored_quant8_3,
            reduce_min::get_examples_quant8_3());
}

TEST_F(GeneratedTests, reduce_min_4) {
    execute(reduce_min::CreateModel_4,
            reduce_min::is_ignored_4,
            reduce_min::get_examples_4());
}

TEST_F(GeneratedTests, reduce_min_quant8_4) {
    execute(reduce_min::CreateModel_quant8_4,
            reduce_min::is_ignored_quant8_4,
            reduce_min::get_examples_quant8_4());
}

