// clang-format off
// Generated file (from: gather_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_1D_float_nnfw {
// Generated gather_1D_float_nnfw test
#include "generated/examples/gather_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_1D_float_nnfw.model.cpp"
} // namespace gather_1D_float_nnfw

TEST_F(GeneratedTests, gather_1D_float_nnfw) {
    execute(gather_1D_float_nnfw::CreateModel,
            gather_1D_float_nnfw::is_ignored,
            gather_1D_float_nnfw::get_examples());
}

