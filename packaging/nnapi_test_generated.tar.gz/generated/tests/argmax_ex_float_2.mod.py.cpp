// clang-format off
// Generated file (from: argmax_ex_float_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_ex_float_2 {
// Generated argmax_ex_float_2 test
#include "generated/examples/argmax_ex_float_2.example.cpp"
// Generated model constructor
#include "generated/models/argmax_ex_float_2.model.cpp"
} // namespace argmax_ex_float_2

TEST_F(GeneratedTests, argmax_ex_float_2) {
    execute(argmax_ex_float_2::CreateModel,
            argmax_ex_float_2::is_ignored,
            argmax_ex_float_2::get_examples());
}

