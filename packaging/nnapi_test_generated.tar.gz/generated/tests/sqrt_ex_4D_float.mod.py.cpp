// clang-format off
// Generated file (from: sqrt_ex_4D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sqrt_ex_4D_float {
// Generated sqrt_ex_4D_float test
#include "generated/examples/sqrt_ex_4D_float.example.cpp"
// Generated model constructor
#include "generated/models/sqrt_ex_4D_float.model.cpp"
} // namespace sqrt_ex_4D_float

TEST_F(GeneratedTests, sqrt_ex_4D_float) {
    execute(sqrt_ex_4D_float::CreateModel,
            sqrt_ex_4D_float::is_ignored,
            sqrt_ex_4D_float::get_examples());
}

