// clang-format off
// Generated file (from: equal.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace equal {
// Generated equal test
#include "generated/examples/equal.example.cpp"
// Generated model constructor
#include "generated/models/equal.model.cpp"
} // namespace equal

TEST_F(GeneratedTests, equal_simple) {
    execute(equal::CreateModel,
            equal::is_ignored,
            equal::get_examples_simple());
}

TEST_F(GeneratedTests, equal_broadcast) {
    execute(equal::CreateModel_2,
            equal::is_ignored_2,
            equal::get_examples_broadcast());
}

TEST_F(GeneratedTests, equal_quantized_different_scale) {
    execute(equal::CreateModel_3,
            equal::is_ignored_3,
            equal::get_examples_quantized_different_scale());
}

TEST_F(GeneratedTests, equal_quantized_different_zero_point) {
    execute(equal::CreateModel_4,
            equal::is_ignored_4,
            equal::get_examples_quantized_different_zero_point());
}

TEST_F(GeneratedTests, equal_quantized_overflow_second_input_if_requantized) {
    execute(equal::CreateModel_5,
            equal::is_ignored_5,
            equal::get_examples_quantized_overflow_second_input_if_requantized());
}

TEST_F(GeneratedTests, equal_quantized_overflow_first_input_if_requantized) {
    execute(equal::CreateModel_6,
            equal::is_ignored_6,
            equal::get_examples_quantized_overflow_first_input_if_requantized());
}

TEST_F(GeneratedTests, equal_boolean) {
    execute(equal::CreateModel_7,
            equal::is_ignored_7,
            equal::get_examples_boolean());
}

