// clang-format off
// Generated file (from: mean_4D_float_reducing_C_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mean_4D_float_reducing_C_nnfw {
// Generated mean_4D_float_reducing_C_nnfw test
#include "generated/examples/mean_4D_float_reducing_C_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mean_4D_float_reducing_C_nnfw.model.cpp"
} // namespace mean_4D_float_reducing_C_nnfw

TEST_F(GeneratedTests, mean_4D_float_reducing_C_nnfw) {
    execute(mean_4D_float_reducing_C_nnfw::CreateModel,
            mean_4D_float_reducing_C_nnfw::is_ignored,
            mean_4D_float_reducing_C_nnfw::get_examples());
}

