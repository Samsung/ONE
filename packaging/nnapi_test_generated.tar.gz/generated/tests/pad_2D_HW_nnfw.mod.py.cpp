// clang-format off
// Generated file (from: pad_2D_HW_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_2D_HW_nnfw {
// Generated pad_2D_HW_nnfw test
#include "generated/examples/pad_2D_HW_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_2D_HW_nnfw.model.cpp"
} // namespace pad_2D_HW_nnfw

TEST_F(GeneratedTests, pad_2D_HW_nnfw) {
    execute(pad_2D_HW_nnfw::CreateModel,
            pad_2D_HW_nnfw::is_ignored,
            pad_2D_HW_nnfw::get_examples());
}

