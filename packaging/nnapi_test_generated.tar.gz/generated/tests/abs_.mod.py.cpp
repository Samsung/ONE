// clang-format off
// Generated file (from: abs_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace abs_ {
// Generated abs_ test
#include "generated/examples/abs_.example.cpp"
// Generated model constructor
#include "generated/models/abs_.model.cpp"
} // namespace abs_

TEST_F(GeneratedTests, abs_) {
    execute(abs_::CreateModel,
            abs_::is_ignored,
            abs_::get_examples());
}

