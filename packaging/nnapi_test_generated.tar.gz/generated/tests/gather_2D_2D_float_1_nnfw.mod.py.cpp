// clang-format off
// Generated file (from: gather_2D_2D_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_2D_2D_float_1_nnfw {
// Generated gather_2D_2D_float_1_nnfw test
#include "generated/examples/gather_2D_2D_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_2D_2D_float_1_nnfw.model.cpp"
} // namespace gather_2D_2D_float_1_nnfw

TEST_F(GeneratedTests, gather_2D_2D_float_1_nnfw) {
    execute(gather_2D_2D_float_1_nnfw::CreateModel,
            gather_2D_2D_float_1_nnfw::is_ignored,
            gather_2D_2D_float_1_nnfw::get_examples());
}

