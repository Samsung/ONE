// clang-format off
// Generated file (from: concat_float_4D_axis3_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace concat_float_4D_axis3_1_nnfw {
// Generated concat_float_4D_axis3_1_nnfw test
#include "generated/examples/concat_float_4D_axis3_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/concat_float_4D_axis3_1_nnfw.model.cpp"
} // namespace concat_float_4D_axis3_1_nnfw

TEST_F(GeneratedTests, concat_float_4D_axis3_1_nnfw) {
    execute(concat_float_4D_axis3_1_nnfw::CreateModel,
            concat_float_4D_axis3_1_nnfw::is_ignored,
            concat_float_4D_axis3_1_nnfw::get_examples());
}

