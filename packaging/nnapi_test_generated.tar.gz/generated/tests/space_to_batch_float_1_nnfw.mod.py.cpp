// clang-format off
// Generated file (from: space_to_batch_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace space_to_batch_float_1_nnfw {
// Generated space_to_batch_float_1_nnfw test
#include "generated/examples/space_to_batch_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/space_to_batch_float_1_nnfw.model.cpp"
} // namespace space_to_batch_float_1_nnfw

TEST_F(GeneratedTests, space_to_batch_float_1_nnfw) {
    execute(space_to_batch_float_1_nnfw::CreateModel,
            space_to_batch_float_1_nnfw::is_ignored,
            space_to_batch_float_1_nnfw::get_examples());
}

