// clang-format off
// Generated file (from: reduce_sum.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_sum {
// Generated reduce_sum test
#include "generated/examples/reduce_sum.example.cpp"
// Generated model constructor
#include "generated/models/reduce_sum.model.cpp"
} // namespace reduce_sum

TEST_F(GeneratedTests, reduce_sum) {
    execute(reduce_sum::CreateModel,
            reduce_sum::is_ignored,
            reduce_sum::get_examples());
}

TEST_F(GeneratedTests, reduce_sum_2) {
    execute(reduce_sum::CreateModel_2,
            reduce_sum::is_ignored_2,
            reduce_sum::get_examples_2());
}

TEST_F(GeneratedTests, reduce_sum_3) {
    execute(reduce_sum::CreateModel_3,
            reduce_sum::is_ignored_3,
            reduce_sum::get_examples_3());
}

TEST_F(GeneratedTests, reduce_sum_4) {
    execute(reduce_sum::CreateModel_4,
            reduce_sum::is_ignored_4,
            reduce_sum::get_examples_4());
}

