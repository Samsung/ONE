// clang-format off
// Generated file (from: pad_HWD_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_HWD_nnfw {
// Generated pad_HWD_nnfw test
#include "generated/examples/pad_HWD_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_HWD_nnfw.model.cpp"
} // namespace pad_HWD_nnfw

TEST_F(GeneratedTests, pad_HWD_nnfw) {
    execute(pad_HWD_nnfw::CreateModel,
            pad_HWD_nnfw::is_ignored,
            pad_HWD_nnfw::get_examples());
}

