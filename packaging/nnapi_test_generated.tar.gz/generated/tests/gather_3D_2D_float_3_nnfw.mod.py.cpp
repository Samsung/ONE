// clang-format off
// Generated file (from: gather_3D_2D_float_3_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_3D_2D_float_3_nnfw {
// Generated gather_3D_2D_float_3_nnfw test
#include "generated/examples/gather_3D_2D_float_3_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_3D_2D_float_3_nnfw.model.cpp"
} // namespace gather_3D_2D_float_3_nnfw

TEST_F(GeneratedTests, gather_3D_2D_float_3_nnfw) {
    execute(gather_3D_2D_float_3_nnfw::CreateModel,
            gather_3D_2D_float_3_nnfw::is_ignored,
            gather_3D_2D_float_3_nnfw::get_examples());
}

