// clang-format off
// Generated file (from: unpack_ex_3D_int_1.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace unpack_ex_3D_int_1 {
// Generated unpack_ex_3D_int_1 test
#include "generated/examples/unpack_ex_3D_int_1.example.cpp"
// Generated model constructor
#include "generated/models/unpack_ex_3D_int_1.model.cpp"
} // namespace unpack_ex_3D_int_1

TEST_F(GeneratedTests, unpack_ex_3D_int_1) {
    execute(unpack_ex_3D_int_1::CreateModel,
            unpack_ex_3D_int_1::is_ignored,
            unpack_ex_3D_int_1::get_examples());
}

