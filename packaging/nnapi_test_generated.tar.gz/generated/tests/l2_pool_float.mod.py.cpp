// clang-format off
// Generated file (from: l2_pool_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace l2_pool_float {
// Generated l2_pool_float test
#include "generated/examples/l2_pool_float.example.cpp"
// Generated model constructor
#include "generated/models/l2_pool_float.model.cpp"
} // namespace l2_pool_float

TEST_F(GeneratedTests, l2_pool_float) {
    execute(l2_pool_float::CreateModel,
            l2_pool_float::is_ignored,
            l2_pool_float::get_examples());
}

