// clang-format off
// Generated file (from: less_ex.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace less_ex {
// Generated less_ex test
#include "generated/examples/less_ex.example.cpp"
// Generated model constructor
#include "generated/models/less_ex.model.cpp"
} // namespace less_ex

TEST_F(GeneratedTests, less_ex) {
    execute(less_ex::CreateModel,
            less_ex::is_ignored,
            less_ex::get_examples());
}

