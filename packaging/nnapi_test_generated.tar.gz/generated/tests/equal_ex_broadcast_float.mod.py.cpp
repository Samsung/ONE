// clang-format off
// Generated file (from: equal_ex_broadcast_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace equal_ex_broadcast_float {
// Generated equal_ex_broadcast_float test
#include "generated/examples/equal_ex_broadcast_float.example.cpp"
// Generated model constructor
#include "generated/models/equal_ex_broadcast_float.model.cpp"
} // namespace equal_ex_broadcast_float

TEST_F(GeneratedTests, equal_ex_broadcast_float) {
    execute(equal_ex_broadcast_float::CreateModel,
            equal_ex_broadcast_float::is_ignored,
            equal_ex_broadcast_float::get_examples());
}

