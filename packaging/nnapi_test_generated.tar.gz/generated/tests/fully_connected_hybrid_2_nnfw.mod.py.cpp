// clang-format off
// Generated file (from: fully_connected_hybrid_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace fully_connected_hybrid_2_nnfw {
// Generated fully_connected_hybrid_2_nnfw test
#include "generated/examples/fully_connected_hybrid_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/fully_connected_hybrid_2_nnfw.model.cpp"
} // namespace fully_connected_hybrid_2_nnfw

TEST_F(GeneratedTests, fully_connected_hybrid_2_nnfw) {
    execute(fully_connected_hybrid_2_nnfw::CreateModel,
            fully_connected_hybrid_2_nnfw::is_ignored,
            fully_connected_hybrid_2_nnfw::get_examples());
}

