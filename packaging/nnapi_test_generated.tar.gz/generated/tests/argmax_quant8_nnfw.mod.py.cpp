// clang-format off
// Generated file (from: argmax_quant8_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_quant8_nnfw {
// Generated argmax_quant8_nnfw test
#include "generated/examples/argmax_quant8_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/argmax_quant8_nnfw.model.cpp"
} // namespace argmax_quant8_nnfw

TEST_F(GeneratedTests, argmax_quant8_nnfw) {
    execute(argmax_quant8_nnfw::CreateModel,
            argmax_quant8_nnfw::is_ignored,
            argmax_quant8_nnfw::get_examples());
}

