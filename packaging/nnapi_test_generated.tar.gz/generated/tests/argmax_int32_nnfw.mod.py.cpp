// clang-format off
// Generated file (from: argmax_int32_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_int32_nnfw {
// Generated argmax_int32_nnfw test
#include "generated/examples/argmax_int32_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/argmax_int32_nnfw.model.cpp"
} // namespace argmax_int32_nnfw

TEST_F(GeneratedTests, argmax_int32_nnfw) {
    execute(argmax_int32_nnfw::CreateModel,
            argmax_int32_nnfw::is_ignored,
            argmax_int32_nnfw::get_examples());
}

