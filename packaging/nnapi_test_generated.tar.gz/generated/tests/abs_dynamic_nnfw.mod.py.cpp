// clang-format off
// Generated file (from: abs_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace abs_dynamic_nnfw {
// Generated abs_dynamic_nnfw test
#include "generated/examples/abs_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/abs_dynamic_nnfw.model.cpp"
} // namespace abs_dynamic_nnfw

TEST_F(GeneratedTests, abs_dynamic_nnfw) {
    execute(abs_dynamic_nnfw::CreateModel,
            abs_dynamic_nnfw::is_ignored,
            abs_dynamic_nnfw::get_examples());
}

