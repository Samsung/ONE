// clang-format off
// Generated file (from: gather_3D_2D_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_3D_2D_float_1_nnfw {
// Generated gather_3D_2D_float_1_nnfw test
#include "generated/examples/gather_3D_2D_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_3D_2D_float_1_nnfw.model.cpp"
} // namespace gather_3D_2D_float_1_nnfw

TEST_F(GeneratedTests, gather_3D_2D_float_1_nnfw) {
    execute(gather_3D_2D_float_1_nnfw::CreateModel,
            gather_3D_2D_float_1_nnfw::is_ignored,
            gather_3D_2D_float_1_nnfw::get_examples());
}

