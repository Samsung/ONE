// clang-format off
// Generated file (from: space_to_batch_quant8_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace space_to_batch_quant8_2_nnfw {
// Generated space_to_batch_quant8_2_nnfw test
#include "generated/examples/space_to_batch_quant8_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/space_to_batch_quant8_2_nnfw.model.cpp"
} // namespace space_to_batch_quant8_2_nnfw

TEST_F(GeneratedTests, space_to_batch_quant8_2_nnfw) {
    execute(space_to_batch_quant8_2_nnfw::CreateModel,
            space_to_batch_quant8_2_nnfw::is_ignored,
            space_to_batch_quant8_2_nnfw::get_examples());
}

