// clang-format off
// Generated file (from: mul_broadcast_3D_1D_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mul_broadcast_3D_1D_1_nnfw {
// Generated mul_broadcast_3D_1D_1_nnfw test
#include "generated/examples/mul_broadcast_3D_1D_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mul_broadcast_3D_1D_1_nnfw.model.cpp"
} // namespace mul_broadcast_3D_1D_1_nnfw

TEST_F(GeneratedTests, mul_broadcast_3D_1D_1_nnfw) {
    execute(mul_broadcast_3D_1D_1_nnfw::CreateModel,
            mul_broadcast_3D_1D_1_nnfw::is_ignored,
            mul_broadcast_3D_1D_1_nnfw::get_examples());
}

