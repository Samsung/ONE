// clang-format off
// Generated file (from: exp_ex_1D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace exp_ex_1D_float {
// Generated exp_ex_1D_float test
#include "generated/examples/exp_ex_1D_float.example.cpp"
// Generated model constructor
#include "generated/models/exp_ex_1D_float.model.cpp"
} // namespace exp_ex_1D_float

TEST_F(GeneratedTests, exp_ex_1D_float) {
    execute(exp_ex_1D_float::CreateModel,
            exp_ex_1D_float::is_ignored,
            exp_ex_1D_float::get_examples());
}

