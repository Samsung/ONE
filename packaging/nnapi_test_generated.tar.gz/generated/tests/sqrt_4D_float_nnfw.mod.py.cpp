// clang-format off
// Generated file (from: sqrt_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sqrt_4D_float_nnfw {
// Generated sqrt_4D_float_nnfw test
#include "generated/examples/sqrt_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/sqrt_4D_float_nnfw.model.cpp"
} // namespace sqrt_4D_float_nnfw

TEST_F(GeneratedTests, sqrt_4D_float_nnfw) {
    execute(sqrt_4D_float_nnfw::CreateModel,
            sqrt_4D_float_nnfw::is_ignored,
            sqrt_4D_float_nnfw::get_examples());
}

