// clang-format off
// Generated file (from: argmax_neg_axis_int32_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_neg_axis_int32_nnfw {
// Generated argmax_neg_axis_int32_nnfw test
#include "generated/examples/argmax_neg_axis_int32_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/argmax_neg_axis_int32_nnfw.model.cpp"
} // namespace argmax_neg_axis_int32_nnfw

TEST_F(GeneratedTests, argmax_neg_axis_int32_nnfw) {
    execute(argmax_neg_axis_int32_nnfw::CreateModel,
            argmax_neg_axis_int32_nnfw::is_ignored,
            argmax_neg_axis_int32_nnfw::get_examples());
}

