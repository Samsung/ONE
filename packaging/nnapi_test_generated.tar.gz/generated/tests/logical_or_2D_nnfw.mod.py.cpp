// clang-format off
// Generated file (from: logical_or_2D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_or_2D_nnfw {
// Generated logical_or_2D_nnfw test
#include "generated/examples/logical_or_2D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/logical_or_2D_nnfw.model.cpp"
} // namespace logical_or_2D_nnfw

TEST_F(GeneratedTests, logical_or_2D_nnfw) {
    execute(logical_or_2D_nnfw::CreateModel,
            logical_or_2D_nnfw::is_ignored,
            logical_or_2D_nnfw::get_examples());
}

