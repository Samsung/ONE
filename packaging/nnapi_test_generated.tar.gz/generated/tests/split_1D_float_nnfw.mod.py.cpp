// clang-format off
// Generated file (from: split_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_1D_float_nnfw {
// Generated split_1D_float_nnfw test
#include "generated/examples/split_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/split_1D_float_nnfw.model.cpp"
} // namespace split_1D_float_nnfw

TEST_F(GeneratedTests, split_1D_float_nnfw) {
    execute(split_1D_float_nnfw::CreateModel,
            split_1D_float_nnfw::is_ignored,
            split_1D_float_nnfw::get_examples());
}

