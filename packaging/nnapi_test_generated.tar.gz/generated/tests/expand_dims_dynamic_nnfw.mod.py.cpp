// clang-format off
// Generated file (from: expand_dims_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace expand_dims_dynamic_nnfw {
// Generated expand_dims_dynamic_nnfw test
#include "generated/examples/expand_dims_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/expand_dims_dynamic_nnfw.model.cpp"
} // namespace expand_dims_dynamic_nnfw

TEST_F(GeneratedTests, expand_dims_dynamic_nnfw_1) {
    execute(expand_dims_dynamic_nnfw::CreateModel,
            expand_dims_dynamic_nnfw::is_ignored,
            expand_dims_dynamic_nnfw::get_examples_1());
}

TEST_F(GeneratedTests, expand_dims_dynamic_nnfw_2) {
    execute(expand_dims_dynamic_nnfw::CreateModel_2,
            expand_dims_dynamic_nnfw::is_ignored_2,
            expand_dims_dynamic_nnfw::get_examples_2());
}

