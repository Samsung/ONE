// clang-format off
// Generated file (from: cast_int32_to_float32_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace cast_int32_to_float32_nnfw {
// Generated cast_int32_to_float32_nnfw test
#include "generated/examples/cast_int32_to_float32_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/cast_int32_to_float32_nnfw.model.cpp"
} // namespace cast_int32_to_float32_nnfw

TEST_F(GeneratedTests, cast_int32_to_float32_nnfw) {
    execute(cast_int32_to_float32_nnfw::CreateModel,
            cast_int32_to_float32_nnfw::is_ignored,
            cast_int32_to_float32_nnfw::get_examples());
}

