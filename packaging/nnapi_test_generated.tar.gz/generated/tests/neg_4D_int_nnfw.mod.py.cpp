// clang-format off
// Generated file (from: neg_4D_int_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace neg_4D_int_nnfw {
// Generated neg_4D_int_nnfw test
#include "generated/examples/neg_4D_int_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/neg_4D_int_nnfw.model.cpp"
} // namespace neg_4D_int_nnfw

TEST_F(GeneratedTests, neg_4D_int_nnfw) {
    execute(neg_4D_int_nnfw::CreateModel,
            neg_4D_int_nnfw::is_ignored,
            neg_4D_int_nnfw::get_examples());
}

