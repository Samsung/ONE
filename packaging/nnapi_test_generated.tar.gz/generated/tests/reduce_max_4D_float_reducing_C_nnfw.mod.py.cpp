// clang-format off
// Generated file (from: reduce_max_4D_float_reducing_C_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max_4D_float_reducing_C_nnfw {
// Generated reduce_max_4D_float_reducing_C_nnfw test
#include "generated/examples/reduce_max_4D_float_reducing_C_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max_4D_float_reducing_C_nnfw.model.cpp"
} // namespace reduce_max_4D_float_reducing_C_nnfw

TEST_F(GeneratedTests, reduce_max_4D_float_reducing_C_nnfw) {
    execute(reduce_max_4D_float_reducing_C_nnfw::CreateModel,
            reduce_max_4D_float_reducing_C_nnfw::is_ignored,
            reduce_max_4D_float_reducing_C_nnfw::get_examples());
}

