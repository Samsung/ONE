// clang-format off
// Generated file (from: rsqrt.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace rsqrt {
// Generated rsqrt test
#include "generated/examples/rsqrt.example.cpp"
// Generated model constructor
#include "generated/models/rsqrt.model.cpp"
} // namespace rsqrt

TEST_F(GeneratedTests, rsqrt) {
    execute(rsqrt::CreateModel,
            rsqrt::is_ignored,
            rsqrt::get_examples());
}

