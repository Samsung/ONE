// clang-format off
// Generated file (from: rsqrt_3D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace rsqrt_3D_float_nnfw {
// Generated rsqrt_3D_float_nnfw test
#include "generated/examples/rsqrt_3D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/rsqrt_3D_float_nnfw.model.cpp"
} // namespace rsqrt_3D_float_nnfw

TEST_F(GeneratedTests, rsqrt_3D_float_nnfw) {
    execute(rsqrt_3D_float_nnfw::CreateModel,
            rsqrt_3D_float_nnfw::is_ignored,
            rsqrt_3D_float_nnfw::get_examples());
}

