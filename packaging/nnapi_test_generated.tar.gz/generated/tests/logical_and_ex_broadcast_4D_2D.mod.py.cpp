// clang-format off
// Generated file (from: logical_and_ex_broadcast_4D_2D.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_and_ex_broadcast_4D_2D {
// Generated logical_and_ex_broadcast_4D_2D test
#include "generated/examples/logical_and_ex_broadcast_4D_2D.example.cpp"
// Generated model constructor
#include "generated/models/logical_and_ex_broadcast_4D_2D.model.cpp"
} // namespace logical_and_ex_broadcast_4D_2D

TEST_F(GeneratedTests, logical_and_ex_broadcast_4D_2D) {
    execute(logical_and_ex_broadcast_4D_2D::CreateModel,
            logical_and_ex_broadcast_4D_2D::is_ignored,
            logical_and_ex_broadcast_4D_2D::get_examples());
}

