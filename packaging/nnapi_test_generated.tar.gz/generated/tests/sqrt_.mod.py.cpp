// clang-format off
// Generated file (from: sqrt_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sqrt_ {
// Generated sqrt_ test
#include "generated/examples/sqrt_.example.cpp"
// Generated model constructor
#include "generated/models/sqrt_.model.cpp"
} // namespace sqrt_

TEST_F(GeneratedTests, sqrt_) {
    execute(sqrt_::CreateModel,
            sqrt_::is_ignored,
            sqrt_::get_examples());
}

