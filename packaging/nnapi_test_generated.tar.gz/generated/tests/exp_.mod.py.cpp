// clang-format off
// Generated file (from: exp_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace exp_ {
// Generated exp_ test
#include "generated/examples/exp_.example.cpp"
// Generated model constructor
#include "generated/models/exp_.model.cpp"
} // namespace exp_

TEST_F(GeneratedTests, exp_) {
    execute(exp_::CreateModel,
            exp_::is_ignored,
            exp_::get_examples());
}

