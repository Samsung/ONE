// clang-format off
// Generated file (from: topk_v2_ex_2D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace topk_v2_ex_2D_float {
// Generated topk_v2_ex_2D_float test
#include "generated/examples/topk_v2_ex_2D_float.example.cpp"
// Generated model constructor
#include "generated/models/topk_v2_ex_2D_float.model.cpp"
} // namespace topk_v2_ex_2D_float

TEST_F(GeneratedTests, topk_v2_ex_2D_float) {
    execute(topk_v2_ex_2D_float::CreateModel,
            topk_v2_ex_2D_float::is_ignored,
            topk_v2_ex_2D_float::get_examples());
}

