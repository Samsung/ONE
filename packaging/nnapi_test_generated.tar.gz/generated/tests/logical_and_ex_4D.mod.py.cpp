// clang-format off
// Generated file (from: logical_and_ex_4D.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_and_ex_4D {
// Generated logical_and_ex_4D test
#include "generated/examples/logical_and_ex_4D.example.cpp"
// Generated model constructor
#include "generated/models/logical_and_ex_4D.model.cpp"
} // namespace logical_and_ex_4D

TEST_F(GeneratedTests, logical_and_ex_4D) {
    execute(logical_and_ex_4D::CreateModel,
            logical_and_ex_4D::is_ignored,
            logical_and_ex_4D::get_examples());
}

