// clang-format off
// Generated file (from: equal_broadcast_4D_2D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace equal_broadcast_4D_2D_float_nnfw {
// Generated equal_broadcast_4D_2D_float_nnfw test
#include "generated/examples/equal_broadcast_4D_2D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/equal_broadcast_4D_2D_float_nnfw.model.cpp"
} // namespace equal_broadcast_4D_2D_float_nnfw

TEST_F(GeneratedTests, equal_broadcast_4D_2D_float_nnfw) {
    execute(equal_broadcast_4D_2D_float_nnfw::CreateModel,
            equal_broadcast_4D_2D_float_nnfw::is_ignored,
            equal_broadcast_4D_2D_float_nnfw::get_examples());
}

