// clang-format off
// Generated file (from: reduce_sum_ex_4D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_sum_ex_4D_float {
// Generated reduce_sum_ex_4D_float test
#include "generated/examples/reduce_sum_ex_4D_float.example.cpp"
// Generated model constructor
#include "generated/models/reduce_sum_ex_4D_float.model.cpp"
} // namespace reduce_sum_ex_4D_float

TEST_F(GeneratedTests, reduce_sum_ex_4D_float) {
    execute(reduce_sum_ex_4D_float::CreateModel,
            reduce_sum_ex_4D_float::is_ignored,
            reduce_sum_ex_4D_float::get_examples());
}

