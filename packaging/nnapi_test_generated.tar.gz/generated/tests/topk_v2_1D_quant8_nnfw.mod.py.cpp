// clang-format off
// Generated file (from: topk_v2_1D_quant8_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace topk_v2_1D_quant8_nnfw {
// Generated topk_v2_1D_quant8_nnfw test
#include "generated/examples/topk_v2_1D_quant8_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/topk_v2_1D_quant8_nnfw.model.cpp"
} // namespace topk_v2_1D_quant8_nnfw

TEST_F(GeneratedTests, topk_v2_1D_quant8_nnfw) {
    execute(topk_v2_1D_quant8_nnfw::CreateModel,
            topk_v2_1D_quant8_nnfw::is_ignored,
            topk_v2_1D_quant8_nnfw::get_examples());
}

