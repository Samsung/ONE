// clang-format off
// Generated file (from: gather_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_4D_float_nnfw {
// Generated gather_4D_float_nnfw test
#include "generated/examples/gather_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_4D_float_nnfw.model.cpp"
} // namespace gather_4D_float_nnfw

TEST_F(GeneratedTests, gather_4D_float_nnfw) {
    execute(gather_4D_float_nnfw::CreateModel,
            gather_4D_float_nnfw::is_ignored,
            gather_4D_float_nnfw::get_examples());
}

