// clang-format off
// Generated file (from: zeros_like_ex_2D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace zeros_like_ex_2D_float {
// Generated zeros_like_ex_2D_float test
#include "generated/examples/zeros_like_ex_2D_float.example.cpp"
// Generated model constructor
#include "generated/models/zeros_like_ex_2D_float.model.cpp"
} // namespace zeros_like_ex_2D_float

TEST_F(GeneratedTests, zeros_like_ex_2D_float) {
    execute(zeros_like_ex_2D_float::CreateModel,
            zeros_like_ex_2D_float::is_ignored,
            zeros_like_ex_2D_float::get_examples());
}

