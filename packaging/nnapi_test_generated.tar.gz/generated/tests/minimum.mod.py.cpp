// clang-format off
// Generated file (from: minimum.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace minimum {
// Generated minimum test
#include "generated/examples/minimum.example.cpp"
// Generated model constructor
#include "generated/models/minimum.model.cpp"
} // namespace minimum

TEST_F(GeneratedTests, minimum_simple) {
    execute(minimum::CreateModel,
            minimum::is_ignored,
            minimum::get_examples_simple());
}

TEST_F(GeneratedTests, minimum_simple_quant8) {
    execute(minimum::CreateModel_quant8,
            minimum::is_ignored_quant8,
            minimum::get_examples_simple_quant8());
}

TEST_F(GeneratedTests, minimum_broadcast) {
    execute(minimum::CreateModel_2,
            minimum::is_ignored_2,
            minimum::get_examples_broadcast());
}

TEST_F(GeneratedTests, minimum_broadcast_quant8) {
    execute(minimum::CreateModel_quant8_2,
            minimum::is_ignored_quant8_2,
            minimum::get_examples_broadcast_quant8());
}

TEST_F(GeneratedTests, minimum_overflow) {
    execute(minimum::CreateModel_3,
            minimum::is_ignored_3,
            minimum::get_examples_overflow());
}

