// clang-format off
// Generated file (from: logical_and_1D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_and_1D_nnfw {
// Generated logical_and_1D_nnfw test
#include "generated/examples/logical_and_1D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/logical_and_1D_nnfw.model.cpp"
} // namespace logical_and_1D_nnfw

TEST_F(GeneratedTests, logical_and_1D_nnfw) {
    execute(logical_and_1D_nnfw::CreateModel,
            logical_and_1D_nnfw::is_ignored,
            logical_and_1D_nnfw::get_examples());
}

