// clang-format off
// Generated file (from: not_equal_broadcast_4D_2D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace not_equal_broadcast_4D_2D_float_nnfw {
// Generated not_equal_broadcast_4D_2D_float_nnfw test
#include "generated/examples/not_equal_broadcast_4D_2D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/not_equal_broadcast_4D_2D_float_nnfw.model.cpp"
} // namespace not_equal_broadcast_4D_2D_float_nnfw

TEST_F(GeneratedTests, not_equal_broadcast_4D_2D_float_nnfw) {
    execute(not_equal_broadcast_4D_2D_float_nnfw::CreateModel,
            not_equal_broadcast_4D_2D_float_nnfw::is_ignored,
            not_equal_broadcast_4D_2D_float_nnfw::get_examples());
}

