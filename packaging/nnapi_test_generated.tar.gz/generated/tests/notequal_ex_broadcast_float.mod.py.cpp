// clang-format off
// Generated file (from: notequal_ex_broadcast_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace notequal_ex_broadcast_float {
// Generated notequal_ex_broadcast_float test
#include "generated/examples/notequal_ex_broadcast_float.example.cpp"
// Generated model constructor
#include "generated/models/notequal_ex_broadcast_float.model.cpp"
} // namespace notequal_ex_broadcast_float

TEST_F(GeneratedTests, notequal_ex_broadcast_float) {
    execute(notequal_ex_broadcast_float::CreateModel,
            notequal_ex_broadcast_float::is_ignored,
            notequal_ex_broadcast_float::get_examples());
}

