// clang-format off
// Generated file (from: sin_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sin_1D_float_nnfw {
// Generated sin_1D_float_nnfw test
#include "generated/examples/sin_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/sin_1D_float_nnfw.model.cpp"
} // namespace sin_1D_float_nnfw

TEST_F(GeneratedTests, sin_1D_float_nnfw) {
    execute(sin_1D_float_nnfw::CreateModel,
            sin_1D_float_nnfw::is_ignored,
            sin_1D_float_nnfw::get_examples());
}

