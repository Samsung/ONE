// clang-format off
// Generated file (from: div_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace div_ {
// Generated div_ test
#include "generated/examples/div_.example.cpp"
// Generated model constructor
#include "generated/models/div_.model.cpp"
} // namespace div_

TEST_F(GeneratedTests, div_) {
    execute(div_::CreateModel,
            div_::is_ignored,
            div_::get_examples());
}

