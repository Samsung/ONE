// clang-format off
// Generated file (from: less.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace less {
// Generated less test
#include "generated/examples/less.example.cpp"
// Generated model constructor
#include "generated/models/less.model.cpp"
} // namespace less

TEST_F(GeneratedTests, less_simple) {
    execute(less::CreateModel,
            less::is_ignored,
            less::get_examples_simple());
}

TEST_F(GeneratedTests, less_broadcast) {
    execute(less::CreateModel_2,
            less::is_ignored_2,
            less::get_examples_broadcast());
}

TEST_F(GeneratedTests, less_quantized_different_scale) {
    execute(less::CreateModel_3,
            less::is_ignored_3,
            less::get_examples_quantized_different_scale());
}

TEST_F(GeneratedTests, less_quantized_different_zero_point) {
    execute(less::CreateModel_4,
            less::is_ignored_4,
            less::get_examples_quantized_different_zero_point());
}

TEST_F(GeneratedTests, less_quantized_overflow_second_input_if_requantized) {
    execute(less::CreateModel_5,
            less::is_ignored_5,
            less::get_examples_quantized_overflow_second_input_if_requantized());
}

TEST_F(GeneratedTests, less_quantized_overflow_first_input_if_requantized) {
    execute(less::CreateModel_6,
            less::is_ignored_6,
            less::get_examples_quantized_overflow_first_input_if_requantized());
}

TEST_F(GeneratedTests, less_boolean) {
    execute(less::CreateModel_7,
            less::is_ignored_7,
            less::get_examples_boolean());
}

