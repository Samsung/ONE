// clang-format off
// Generated file (from: split_4D_float_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_4D_float_2_nnfw {
// Generated split_4D_float_2_nnfw test
#include "generated/examples/split_4D_float_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/split_4D_float_2_nnfw.model.cpp"
} // namespace split_4D_float_2_nnfw

TEST_F(GeneratedTests, split_4D_float_2_nnfw) {
    execute(split_4D_float_2_nnfw::CreateModel,
            split_4D_float_2_nnfw::is_ignored,
            split_4D_float_2_nnfw::get_examples());
}

