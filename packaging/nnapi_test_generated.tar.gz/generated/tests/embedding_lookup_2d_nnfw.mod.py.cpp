// clang-format off
// Generated file (from: embedding_lookup_2d_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace embedding_lookup_2d_nnfw {
// Generated embedding_lookup_2d_nnfw test
#include "generated/examples/embedding_lookup_2d_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/embedding_lookup_2d_nnfw.model.cpp"
} // namespace embedding_lookup_2d_nnfw

TEST_F(GeneratedTests, embedding_lookup_2d_nnfw) {
    execute(embedding_lookup_2d_nnfw::CreateModel,
            embedding_lookup_2d_nnfw::is_ignored,
            embedding_lookup_2d_nnfw::get_examples());
}

