// clang-format off
// Generated file (from: transpose_3D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace transpose_3D_nnfw {
// Generated transpose_3D_nnfw test
#include "generated/examples/transpose_3D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/transpose_3D_nnfw.model.cpp"
} // namespace transpose_3D_nnfw

TEST_F(GeneratedTests, transpose_3D_nnfw) {
    execute(transpose_3D_nnfw::CreateModel,
            transpose_3D_nnfw::is_ignored,
            transpose_3D_nnfw::get_examples());
}

