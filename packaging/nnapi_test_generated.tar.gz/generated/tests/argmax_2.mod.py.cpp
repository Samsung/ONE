// clang-format off
// Generated file (from: argmax_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_2 {
// Generated argmax_2 test
#include "generated/examples/argmax_2.example.cpp"
// Generated model constructor
#include "generated/models/argmax_2.model.cpp"
} // namespace argmax_2

TEST_F(GeneratedTests, argmax_2) {
    execute(argmax_2::CreateModel,
            argmax_2::is_ignored,
            argmax_2::get_examples());
}

TEST_F(GeneratedTests, argmax_2_quant8) {
    execute(argmax_2::CreateModel_quant8,
            argmax_2::is_ignored_quant8,
            argmax_2::get_examples_quant8());
}

