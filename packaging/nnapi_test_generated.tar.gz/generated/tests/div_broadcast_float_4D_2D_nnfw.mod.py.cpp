// clang-format off
// Generated file (from: div_broadcast_float_4D_2D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace div_broadcast_float_4D_2D_nnfw {
// Generated div_broadcast_float_4D_2D_nnfw test
#include "generated/examples/div_broadcast_float_4D_2D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/div_broadcast_float_4D_2D_nnfw.model.cpp"
} // namespace div_broadcast_float_4D_2D_nnfw

TEST_F(GeneratedTests, div_broadcast_float_4D_2D_nnfw) {
    execute(div_broadcast_float_4D_2D_nnfw::CreateModel,
            div_broadcast_float_4D_2D_nnfw::is_ignored,
            div_broadcast_float_4D_2D_nnfw::get_examples());
}

