// clang-format off
// Generated file (from: sin_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sin_4D_float_nnfw {
// Generated sin_4D_float_nnfw test
#include "generated/examples/sin_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/sin_4D_float_nnfw.model.cpp"
} // namespace sin_4D_float_nnfw

TEST_F(GeneratedTests, sin_4D_float_nnfw) {
    execute(sin_4D_float_nnfw::CreateModel,
            sin_4D_float_nnfw::is_ignored,
            sin_4D_float_nnfw::get_examples());
}

