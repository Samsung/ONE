// clang-format off
// Generated file (from: gather_2D_2D_float_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_2D_2D_float_2_nnfw {
// Generated gather_2D_2D_float_2_nnfw test
#include "generated/examples/gather_2D_2D_float_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_2D_2D_float_2_nnfw.model.cpp"
} // namespace gather_2D_2D_float_2_nnfw

TEST_F(GeneratedTests, gather_2D_2D_float_2_nnfw) {
    execute(gather_2D_2D_float_2_nnfw::CreateModel,
            gather_2D_2D_float_2_nnfw::is_ignored,
            gather_2D_2D_float_2_nnfw::get_examples());
}

