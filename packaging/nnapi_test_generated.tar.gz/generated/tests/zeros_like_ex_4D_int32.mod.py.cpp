// clang-format off
// Generated file (from: zeros_like_ex_4D_int32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace zeros_like_ex_4D_int32 {
// Generated zeros_like_ex_4D_int32 test
#include "generated/examples/zeros_like_ex_4D_int32.example.cpp"
// Generated model constructor
#include "generated/models/zeros_like_ex_4D_int32.model.cpp"
} // namespace zeros_like_ex_4D_int32

TEST_F(GeneratedTests, zeros_like_ex_4D_int32) {
    execute(zeros_like_ex_4D_int32::CreateModel,
            zeros_like_ex_4D_int32::is_ignored,
            zeros_like_ex_4D_int32::get_examples());
}

