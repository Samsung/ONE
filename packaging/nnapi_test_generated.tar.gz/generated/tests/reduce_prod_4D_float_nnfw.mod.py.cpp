// clang-format off
// Generated file (from: reduce_prod_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_prod_4D_float_nnfw {
// Generated reduce_prod_4D_float_nnfw test
#include "generated/examples/reduce_prod_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_prod_4D_float_nnfw.model.cpp"
} // namespace reduce_prod_4D_float_nnfw

TEST_F(GeneratedTests, reduce_prod_4D_float_nnfw) {
    execute(reduce_prod_4D_float_nnfw::CreateModel,
            reduce_prod_4D_float_nnfw::is_ignored,
            reduce_prod_4D_float_nnfw::get_examples());
}

