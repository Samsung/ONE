// clang-format off
// Generated file (from: pad_3D_HWC_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_3D_HWC_nnfw {
// Generated pad_3D_HWC_nnfw test
#include "generated/examples/pad_3D_HWC_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_3D_HWC_nnfw.model.cpp"
} // namespace pad_3D_HWC_nnfw

TEST_F(GeneratedTests, pad_3D_HWC_nnfw) {
    execute(pad_3D_HWC_nnfw::CreateModel,
            pad_3D_HWC_nnfw::is_ignored,
            pad_3D_HWC_nnfw::get_examples());
}

