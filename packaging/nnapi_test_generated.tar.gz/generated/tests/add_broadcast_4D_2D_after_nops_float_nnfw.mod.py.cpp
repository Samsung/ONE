// clang-format off
// Generated file (from: add_broadcast_4D_2D_after_nops_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace add_broadcast_4D_2D_after_nops_float_nnfw {
// Generated add_broadcast_4D_2D_after_nops_float_nnfw test
#include "generated/examples/add_broadcast_4D_2D_after_nops_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/add_broadcast_4D_2D_after_nops_float_nnfw.model.cpp"
} // namespace add_broadcast_4D_2D_after_nops_float_nnfw

TEST_F(GeneratedTests, add_broadcast_4D_2D_after_nops_float_nnfw) {
    execute(add_broadcast_4D_2D_after_nops_float_nnfw::CreateModel,
            add_broadcast_4D_2D_after_nops_float_nnfw::is_ignored,
            add_broadcast_4D_2D_after_nops_float_nnfw::get_examples());
}

