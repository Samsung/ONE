// clang-format off
// Generated file (from: slice.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace slice {
// Generated slice test
#include "generated/examples/slice.example.cpp"
// Generated model constructor
#include "generated/models/slice.model.cpp"
} // namespace slice

TEST_F(GeneratedTests, slice) {
    execute(slice::CreateModel,
            slice::is_ignored,
            slice::get_examples());
}

TEST_F(GeneratedTests, slice_2) {
    execute(slice::CreateModel_2,
            slice::is_ignored_2,
            slice::get_examples_2());
}

TEST_F(GeneratedTests, slice_3) {
    execute(slice::CreateModel_3,
            slice::is_ignored_3,
            slice::get_examples_3());
}

TEST_F(GeneratedTests, slice_4) {
    execute(slice::CreateModel_4,
            slice::is_ignored_4,
            slice::get_examples_4());
}

TEST_F(GeneratedTests, slice_5) {
    execute(slice::CreateModel_5,
            slice::is_ignored_5,
            slice::get_examples_5());
}

TEST_F(GeneratedTests, slice_6) {
    execute(slice::CreateModel_6,
            slice::is_ignored_6,
            slice::get_examples_6());
}

TEST_F(GeneratedTests, slice_7) {
    execute(slice::CreateModel_7,
            slice::is_ignored_7,
            slice::get_examples_7());
}

TEST_F(GeneratedTests, slice_8) {
    execute(slice::CreateModel_8,
            slice::is_ignored_8,
            slice::get_examples_8());
}

TEST_F(GeneratedTests, slice_zero_sized) {
    execute(slice::CreateModel_zero_sized,
            slice::is_ignored_zero_sized,
            slice::get_examples_zero_sized());
}

TEST_F(GeneratedTests, slice_zero_sized_quant8) {
    execute(slice::CreateModel_zero_sized_quant8,
            slice::is_ignored_zero_sized_quant8,
            slice::get_examples_zero_sized_quant8());
}

