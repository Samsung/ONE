// clang-format off
// Generated file (from: pad_quant8_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_quant8_nnfw {
// Generated pad_quant8_nnfw test
#include "generated/examples/pad_quant8_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_quant8_nnfw.model.cpp"
} // namespace pad_quant8_nnfw

TEST_F(GeneratedTests, pad_quant8_nnfw) {
    execute(pad_quant8_nnfw::CreateModel,
            pad_quant8_nnfw::is_ignored,
            pad_quant8_nnfw::get_examples());
}

