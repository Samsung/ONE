// clang-format off
// Generated file (from: mul_float_square_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mul_float_square_nnfw {
// Generated mul_float_square_nnfw test
#include "generated/examples/mul_float_square_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mul_float_square_nnfw.model.cpp"
} // namespace mul_float_square_nnfw

TEST_F(GeneratedTests, mul_float_square_nnfw) {
    execute(mul_float_square_nnfw::CreateModel,
            mul_float_square_nnfw::is_ignored,
            mul_float_square_nnfw::get_examples());
}

