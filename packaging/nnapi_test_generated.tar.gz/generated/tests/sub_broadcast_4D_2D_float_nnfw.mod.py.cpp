// clang-format off
// Generated file (from: sub_broadcast_4D_2D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sub_broadcast_4D_2D_float_nnfw {
// Generated sub_broadcast_4D_2D_float_nnfw test
#include "generated/examples/sub_broadcast_4D_2D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/sub_broadcast_4D_2D_float_nnfw.model.cpp"
} // namespace sub_broadcast_4D_2D_float_nnfw

TEST_F(GeneratedTests, sub_broadcast_4D_2D_float_nnfw) {
    execute(sub_broadcast_4D_2D_float_nnfw::CreateModel,
            sub_broadcast_4D_2D_float_nnfw::is_ignored,
            sub_broadcast_4D_2D_float_nnfw::get_examples());
}

