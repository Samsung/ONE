// clang-format off
// Generated file (from: argmax_ex_float_1.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_ex_float_1 {
// Generated argmax_ex_float_1 test
#include "generated/examples/argmax_ex_float_1.example.cpp"
// Generated model constructor
#include "generated/models/argmax_ex_float_1.model.cpp"
} // namespace argmax_ex_float_1

TEST_F(GeneratedTests, argmax_ex_float_1) {
    execute(argmax_ex_float_1::CreateModel,
            argmax_ex_float_1::is_ignored,
            argmax_ex_float_1::get_examples());
}

