// clang-format off
// Generated file (from: unpack_ex_3D_float_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace unpack_ex_3D_float_2 {
// Generated unpack_ex_3D_float_2 test
#include "generated/examples/unpack_ex_3D_float_2.example.cpp"
// Generated model constructor
#include "generated/models/unpack_ex_3D_float_2.model.cpp"
} // namespace unpack_ex_3D_float_2

TEST_F(GeneratedTests, unpack_ex_3D_float_2) {
    execute(unpack_ex_3D_float_2::CreateModel,
            unpack_ex_3D_float_2::is_ignored,
            unpack_ex_3D_float_2::get_examples());
}

