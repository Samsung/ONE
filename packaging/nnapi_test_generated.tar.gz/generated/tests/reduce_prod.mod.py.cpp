// clang-format off
// Generated file (from: reduce_prod.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_prod {
// Generated reduce_prod test
#include "generated/examples/reduce_prod.example.cpp"
// Generated model constructor
#include "generated/models/reduce_prod.model.cpp"
} // namespace reduce_prod

TEST_F(GeneratedTests, reduce_prod) {
    execute(reduce_prod::CreateModel,
            reduce_prod::is_ignored,
            reduce_prod::get_examples());
}

TEST_F(GeneratedTests, reduce_prod_2) {
    execute(reduce_prod::CreateModel_2,
            reduce_prod::is_ignored_2,
            reduce_prod::get_examples_2());
}

TEST_F(GeneratedTests, reduce_prod_3) {
    execute(reduce_prod::CreateModel_3,
            reduce_prod::is_ignored_3,
            reduce_prod::get_examples_3());
}

TEST_F(GeneratedTests, reduce_prod_4) {
    execute(reduce_prod::CreateModel_4,
            reduce_prod::is_ignored_4,
            reduce_prod::get_examples_4());
}

