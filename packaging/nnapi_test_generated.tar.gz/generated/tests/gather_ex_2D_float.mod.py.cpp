// clang-format off
// Generated file (from: gather_ex_2D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_ex_2D_float {
// Generated gather_ex_2D_float test
#include "generated/examples/gather_ex_2D_float.example.cpp"
// Generated model constructor
#include "generated/models/gather_ex_2D_float.model.cpp"
} // namespace gather_ex_2D_float

TEST_F(GeneratedTests, gather_ex_2D_float) {
    execute(gather_ex_2D_float::CreateModel,
            gather_ex_2D_float::is_ignored,
            gather_ex_2D_float::get_examples());
}

