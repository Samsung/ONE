// clang-format off
// Generated file (from: abs_3D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace abs_3D_float_nnfw {
// Generated abs_3D_float_nnfw test
#include "generated/examples/abs_3D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/abs_3D_float_nnfw.model.cpp"
} // namespace abs_3D_float_nnfw

TEST_F(GeneratedTests, abs_3D_float_nnfw) {
    execute(abs_3D_float_nnfw::CreateModel,
            abs_3D_float_nnfw::is_ignored,
            abs_3D_float_nnfw::get_examples());
}

