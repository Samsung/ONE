// clang-format off
// Generated file (from: split_4D_int32_4_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_4D_int32_4_nnfw {
// Generated split_4D_int32_4_nnfw test
#include "generated/examples/split_4D_int32_4_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/split_4D_int32_4_nnfw.model.cpp"
} // namespace split_4D_int32_4_nnfw

TEST_F(GeneratedTests, split_4D_int32_4_nnfw) {
    execute(split_4D_int32_4_nnfw::CreateModel,
            split_4D_int32_4_nnfw::is_ignored,
            split_4D_int32_4_nnfw::get_examples());
}

