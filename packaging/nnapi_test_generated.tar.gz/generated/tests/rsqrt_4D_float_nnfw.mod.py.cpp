// clang-format off
// Generated file (from: rsqrt_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace rsqrt_4D_float_nnfw {
// Generated rsqrt_4D_float_nnfw test
#include "generated/examples/rsqrt_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/rsqrt_4D_float_nnfw.model.cpp"
} // namespace rsqrt_4D_float_nnfw

TEST_F(GeneratedTests, rsqrt_4D_float_nnfw) {
    execute(rsqrt_4D_float_nnfw::CreateModel,
            rsqrt_4D_float_nnfw::is_ignored,
            rsqrt_4D_float_nnfw::get_examples());
}

