// clang-format off
// Generated file (from: exp_1D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace exp_1D_float_nnfw {
// Generated exp_1D_float_nnfw test
#include "generated/examples/exp_1D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/exp_1D_float_nnfw.model.cpp"
} // namespace exp_1D_float_nnfw

TEST_F(GeneratedTests, exp_1D_float_nnfw) {
    execute(exp_1D_float_nnfw::CreateModel,
            exp_1D_float_nnfw::is_ignored,
            exp_1D_float_nnfw::get_examples());
}

