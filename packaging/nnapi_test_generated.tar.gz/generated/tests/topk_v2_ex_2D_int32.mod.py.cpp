// clang-format off
// Generated file (from: topk_v2_ex_2D_int32.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace topk_v2_ex_2D_int32 {
// Generated topk_v2_ex_2D_int32 test
#include "generated/examples/topk_v2_ex_2D_int32.example.cpp"
// Generated model constructor
#include "generated/models/topk_v2_ex_2D_int32.model.cpp"
} // namespace topk_v2_ex_2D_int32

TEST_F(GeneratedTests, topk_v2_ex_2D_int32) {
    execute(topk_v2_ex_2D_int32::CreateModel,
            topk_v2_ex_2D_int32::is_ignored,
            topk_v2_ex_2D_int32::get_examples());
}

