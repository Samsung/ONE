// clang-format off
// Generated file (from: tanh_.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace tanh_ {
// Generated tanh_ test
#include "generated/examples/tanh_.example.cpp"
// Generated model constructor
#include "generated/models/tanh_.model.cpp"
} // namespace tanh_

TEST_F(GeneratedTests, tanh_) {
    execute(tanh_::CreateModel,
            tanh_::is_ignored,
            tanh_::get_examples());
}

