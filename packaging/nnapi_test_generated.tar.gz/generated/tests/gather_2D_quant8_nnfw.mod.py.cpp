// clang-format off
// Generated file (from: gather_2D_quant8_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace gather_2D_quant8_nnfw {
// Generated gather_2D_quant8_nnfw test
#include "generated/examples/gather_2D_quant8_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/gather_2D_quant8_nnfw.model.cpp"
} // namespace gather_2D_quant8_nnfw

TEST_F(GeneratedTests, gather_2D_quant8_nnfw) {
    execute(gather_2D_quant8_nnfw::CreateModel,
            gather_2D_quant8_nnfw::is_ignored,
            gather_2D_quant8_nnfw::get_examples());
}

