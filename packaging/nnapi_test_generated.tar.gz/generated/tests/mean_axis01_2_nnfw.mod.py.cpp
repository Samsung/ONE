// clang-format off
// Generated file (from: mean_axis01_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mean_axis01_2_nnfw {
// Generated mean_axis01_2_nnfw test
#include "generated/examples/mean_axis01_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mean_axis01_2_nnfw.model.cpp"
} // namespace mean_axis01_2_nnfw

TEST_F(GeneratedTests, mean_axis01_2_nnfw) {
    execute(mean_axis01_2_nnfw::CreateModel,
            mean_axis01_2_nnfw::is_ignored,
            mean_axis01_2_nnfw::get_examples());
}

