// clang-format off
// Generated file (from: reduce_prod_4D_float_reducing_C_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_prod_4D_float_reducing_C_nnfw {
// Generated reduce_prod_4D_float_reducing_C_nnfw test
#include "generated/examples/reduce_prod_4D_float_reducing_C_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_prod_4D_float_reducing_C_nnfw.model.cpp"
} // namespace reduce_prod_4D_float_reducing_C_nnfw

TEST_F(GeneratedTests, reduce_prod_4D_float_reducing_C_nnfw) {
    execute(reduce_prod_4D_float_reducing_C_nnfw::CreateModel,
            reduce_prod_4D_float_reducing_C_nnfw::is_ignored,
            reduce_prod_4D_float_reducing_C_nnfw::get_examples());
}

