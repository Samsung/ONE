// clang-format off
// Generated file (from: reverse_ex.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reverse_ex {
// Generated reverse_ex test
#include "generated/examples/reverse_ex.example.cpp"
// Generated model constructor
#include "generated/models/reverse_ex.model.cpp"
} // namespace reverse_ex

TEST_F(GeneratedTests, reverse_ex_1d) {
    execute(reverse_ex::CreateModel,
            reverse_ex::is_ignored,
            reverse_ex::get_examples_1d());
}

TEST_F(GeneratedTests, reverse_ex_3d) {
    execute(reverse_ex::CreateModel_2,
            reverse_ex::is_ignored_2,
            reverse_ex::get_examples_3d());
}

