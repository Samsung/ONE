// clang-format off
// Generated file (from: logical_not_ex_4D.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_not_ex_4D {
// Generated logical_not_ex_4D test
#include "generated/examples/logical_not_ex_4D.example.cpp"
// Generated model constructor
#include "generated/models/logical_not_ex_4D.model.cpp"
} // namespace logical_not_ex_4D

TEST_F(GeneratedTests, logical_not_ex_4D) {
    execute(logical_not_ex_4D::CreateModel,
            logical_not_ex_4D::is_ignored,
            logical_not_ex_4D::get_examples());
}

