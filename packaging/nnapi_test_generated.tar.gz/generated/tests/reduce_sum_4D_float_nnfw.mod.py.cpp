// clang-format off
// Generated file (from: reduce_sum_4D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_sum_4D_float_nnfw {
// Generated reduce_sum_4D_float_nnfw test
#include "generated/examples/reduce_sum_4D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/reduce_sum_4D_float_nnfw.model.cpp"
} // namespace reduce_sum_4D_float_nnfw

TEST_F(GeneratedTests, reduce_sum_4D_float_nnfw) {
    execute(reduce_sum_4D_float_nnfw::CreateModel,
            reduce_sum_4D_float_nnfw::is_ignored,
            reduce_sum_4D_float_nnfw::get_examples());
}

