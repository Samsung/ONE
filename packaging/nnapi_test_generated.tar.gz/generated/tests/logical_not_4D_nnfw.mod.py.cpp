// clang-format off
// Generated file (from: logical_not_4D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace logical_not_4D_nnfw {
// Generated logical_not_4D_nnfw test
#include "generated/examples/logical_not_4D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/logical_not_4D_nnfw.model.cpp"
} // namespace logical_not_4D_nnfw

TEST_F(GeneratedTests, logical_not_4D_nnfw) {
    execute(logical_not_4D_nnfw::CreateModel,
            logical_not_4D_nnfw::is_ignored,
            logical_not_4D_nnfw::get_examples());
}

