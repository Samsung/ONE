// clang-format off
// Generated file (from: pow_broadcast_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pow_broadcast_float_nnfw {
// Generated pow_broadcast_float_nnfw test
#include "generated/examples/pow_broadcast_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pow_broadcast_float_nnfw.model.cpp"
} // namespace pow_broadcast_float_nnfw

TEST_F(GeneratedTests, pow_broadcast_float_nnfw) {
    execute(pow_broadcast_float_nnfw::CreateModel,
            pow_broadcast_float_nnfw::is_ignored,
            pow_broadcast_float_nnfw::get_examples());
}

TEST_F(GeneratedTests, pow_broadcast_float_nnfw_2) {
    execute(pow_broadcast_float_nnfw::CreateModel_2,
            pow_broadcast_float_nnfw::is_ignored_2,
            pow_broadcast_float_nnfw::get_examples_2());
}

TEST_F(GeneratedTests, pow_broadcast_float_nnfw_3) {
    execute(pow_broadcast_float_nnfw::CreateModel_3,
            pow_broadcast_float_nnfw::is_ignored_3,
            pow_broadcast_float_nnfw::get_examples_3());
}

