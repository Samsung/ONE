// clang-format off
// Generated file (from: mul_4D_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mul_4D_nnfw {
// Generated mul_4D_nnfw test
#include "generated/examples/mul_4D_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mul_4D_nnfw.model.cpp"
} // namespace mul_4D_nnfw

TEST_F(GeneratedTests, mul_4D_nnfw) {
    execute(mul_4D_nnfw::CreateModel,
            mul_4D_nnfw::is_ignored,
            mul_4D_nnfw::get_examples());
}

