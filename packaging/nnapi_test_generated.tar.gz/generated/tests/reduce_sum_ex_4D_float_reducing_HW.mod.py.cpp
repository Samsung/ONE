// clang-format off
// Generated file (from: reduce_sum_ex_4D_float_reducing_HW.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_sum_ex_4D_float_reducing_HW {
// Generated reduce_sum_ex_4D_float_reducing_HW test
#include "generated/examples/reduce_sum_ex_4D_float_reducing_HW.example.cpp"
// Generated model constructor
#include "generated/models/reduce_sum_ex_4D_float_reducing_HW.model.cpp"
} // namespace reduce_sum_ex_4D_float_reducing_HW

TEST_F(GeneratedTests, reduce_sum_ex_4D_float_reducing_HW) {
    execute(reduce_sum_ex_4D_float_reducing_HW::CreateModel,
            reduce_sum_ex_4D_float_reducing_HW::is_ignored,
            reduce_sum_ex_4D_float_reducing_HW::get_examples());
}

