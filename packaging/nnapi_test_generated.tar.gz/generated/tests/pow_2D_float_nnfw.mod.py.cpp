// clang-format off
// Generated file (from: pow_2D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pow_2D_float_nnfw {
// Generated pow_2D_float_nnfw test
#include "generated/examples/pow_2D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pow_2D_float_nnfw.model.cpp"
} // namespace pow_2D_float_nnfw

TEST_F(GeneratedTests, pow_2D_float_nnfw) {
    execute(pow_2D_float_nnfw::CreateModel,
            pow_2D_float_nnfw::is_ignored,
            pow_2D_float_nnfw::get_examples());
}

