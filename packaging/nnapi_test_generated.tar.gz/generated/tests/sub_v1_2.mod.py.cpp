// clang-format off
// Generated file (from: sub_v1_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace sub_v1_2 {
// Generated sub_v1_2 test
#include "generated/examples/sub_v1_2.example.cpp"
// Generated model constructor
#include "generated/models/sub_v1_2.model.cpp"
} // namespace sub_v1_2

TEST_F(GeneratedTests, sub_v1_2_none) {
    execute(sub_v1_2::CreateModel_none,
            sub_v1_2::is_ignored_none,
            sub_v1_2::get_examples_none());
}

TEST_F(GeneratedTests, sub_v1_2_relu) {
    execute(sub_v1_2::CreateModel_relu,
            sub_v1_2::is_ignored_relu,
            sub_v1_2::get_examples_relu());
}

TEST_F(GeneratedTests, sub_v1_2_relu1) {
    execute(sub_v1_2::CreateModel_relu1,
            sub_v1_2::is_ignored_relu1,
            sub_v1_2::get_examples_relu1());
}

TEST_F(GeneratedTests, sub_v1_2_relu6) {
    execute(sub_v1_2::CreateModel_relu6,
            sub_v1_2::is_ignored_relu6,
            sub_v1_2::get_examples_relu6());
}

TEST_F(GeneratedTests, sub_v1_2_quant8) {
    execute(sub_v1_2::CreateModel_quant8,
            sub_v1_2::is_ignored_quant8,
            sub_v1_2::get_examples_quant8());
}

TEST_F(GeneratedTests, sub_v1_2_zero_sized) {
    execute(sub_v1_2::CreateModel_zero_sized,
            sub_v1_2::is_ignored_zero_sized,
            sub_v1_2::get_examples_zero_sized());
}

TEST_F(GeneratedTests, sub_v1_2_zero_sized_quant8) {
    execute(sub_v1_2::CreateModel_zero_sized_quant8,
            sub_v1_2::is_ignored_zero_sized_quant8,
            sub_v1_2::get_examples_zero_sized_quant8());
}

