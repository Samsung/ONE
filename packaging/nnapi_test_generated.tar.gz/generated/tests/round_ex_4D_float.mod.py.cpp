// clang-format off
// Generated file (from: round_ex_4D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace round_ex_4D_float {
// Generated round_ex_4D_float test
#include "generated/examples/round_ex_4D_float.example.cpp"
// Generated model constructor
#include "generated/models/round_ex_4D_float.model.cpp"
} // namespace round_ex_4D_float

TEST_F(GeneratedTests, round_ex_4D_float) {
    execute(round_ex_4D_float::CreateModel,
            round_ex_4D_float::is_ignored,
            round_ex_4D_float::get_examples());
}

