// clang-format off
// Generated file (from: squared_difference_ex_3D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace squared_difference_ex_3D_float {
// Generated squared_difference_ex_3D_float test
#include "generated/examples/squared_difference_ex_3D_float.example.cpp"
// Generated model constructor
#include "generated/models/squared_difference_ex_3D_float.model.cpp"
} // namespace squared_difference_ex_3D_float

TEST_F(GeneratedTests, squared_difference_ex_3D_float) {
    execute(squared_difference_ex_3D_float::CreateModel,
            squared_difference_ex_3D_float::is_ignored,
            squared_difference_ex_3D_float::get_examples());
}

