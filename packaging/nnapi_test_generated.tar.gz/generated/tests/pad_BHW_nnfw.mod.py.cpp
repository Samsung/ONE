// clang-format off
// Generated file (from: pad_BHW_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace pad_BHW_nnfw {
// Generated pad_BHW_nnfw test
#include "generated/examples/pad_BHW_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/pad_BHW_nnfw.model.cpp"
} // namespace pad_BHW_nnfw

TEST_F(GeneratedTests, pad_BHW_nnfw) {
    execute(pad_BHW_nnfw::CreateModel,
            pad_BHW_nnfw::is_ignored,
            pad_BHW_nnfw::get_examples());
}

