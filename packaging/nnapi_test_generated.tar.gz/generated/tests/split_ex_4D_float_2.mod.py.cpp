// clang-format off
// Generated file (from: split_ex_4D_float_2.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_ex_4D_float_2 {
// Generated split_ex_4D_float_2 test
#include "generated/examples/split_ex_4D_float_2.example.cpp"
// Generated model constructor
#include "generated/models/split_ex_4D_float_2.model.cpp"
} // namespace split_ex_4D_float_2

TEST_F(GeneratedTests, split_ex_4D_float_2) {
    execute(split_ex_4D_float_2::CreateModel,
            split_ex_4D_float_2::is_ignored,
            split_ex_4D_float_2::get_examples());
}

