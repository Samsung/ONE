// clang-format off
// Generated file (from: less_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace less_nnfw {
// Generated less_nnfw test
#include "generated/examples/less_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/less_nnfw.model.cpp"
} // namespace less_nnfw

TEST_F(GeneratedTests, less_nnfw) {
    execute(less_nnfw::CreateModel,
            less_nnfw::is_ignored,
            less_nnfw::get_examples());
}

