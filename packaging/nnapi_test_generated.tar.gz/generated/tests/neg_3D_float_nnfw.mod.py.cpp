// clang-format off
// Generated file (from: neg_3D_float_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace neg_3D_float_nnfw {
// Generated neg_3D_float_nnfw test
#include "generated/examples/neg_3D_float_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/neg_3D_float_nnfw.model.cpp"
} // namespace neg_3D_float_nnfw

TEST_F(GeneratedTests, neg_3D_float_nnfw) {
    execute(neg_3D_float_nnfw::CreateModel,
            neg_3D_float_nnfw::is_ignored,
            neg_3D_float_nnfw::get_examples());
}

