// clang-format off
// Generated file (from: split_ex_1D_float.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace split_ex_1D_float {
// Generated split_ex_1D_float test
#include "generated/examples/split_ex_1D_float.example.cpp"
// Generated model constructor
#include "generated/models/split_ex_1D_float.model.cpp"
} // namespace split_ex_1D_float

TEST_F(GeneratedTests, split_ex_1D_float) {
    execute(split_ex_1D_float::CreateModel,
            split_ex_1D_float::is_ignored,
            split_ex_1D_float::get_examples());
}

