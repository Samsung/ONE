// clang-format off
// Generated file (from: mean_4D_float_reducing_HW_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace mean_4D_float_reducing_HW_nnfw {
// Generated mean_4D_float_reducing_HW_nnfw test
#include "generated/examples/mean_4D_float_reducing_HW_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/mean_4D_float_reducing_HW_nnfw.model.cpp"
} // namespace mean_4D_float_reducing_HW_nnfw

TEST_F(GeneratedTests, mean_4D_float_reducing_HW_nnfw) {
    execute(mean_4D_float_reducing_HW_nnfw::CreateModel,
            mean_4D_float_reducing_HW_nnfw::is_ignored,
            mean_4D_float_reducing_HW_nnfw::get_examples());
}

