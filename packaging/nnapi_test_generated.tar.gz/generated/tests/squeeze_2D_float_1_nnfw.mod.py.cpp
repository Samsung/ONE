// clang-format off
// Generated file (from: squeeze_2D_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace squeeze_2D_float_1_nnfw {
// Generated squeeze_2D_float_1_nnfw test
#include "generated/examples/squeeze_2D_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/squeeze_2D_float_1_nnfw.model.cpp"
} // namespace squeeze_2D_float_1_nnfw

TEST_F(GeneratedTests, squeeze_2D_float_1_nnfw) {
    execute(squeeze_2D_float_1_nnfw::CreateModel,
            squeeze_2D_float_1_nnfw::is_ignored,
            squeeze_2D_float_1_nnfw::get_examples());
}

