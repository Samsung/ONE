// clang-format off
// Generated file (from: not_equal_quant8_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace not_equal_quant8_nnfw {
// Generated not_equal_quant8_nnfw test
#include "generated/examples/not_equal_quant8_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/not_equal_quant8_nnfw.model.cpp"
} // namespace not_equal_quant8_nnfw

TEST_F(GeneratedTests, not_equal_quant8_nnfw) {
    execute(not_equal_quant8_nnfw::CreateModel,
            not_equal_quant8_nnfw::is_ignored,
            not_equal_quant8_nnfw::get_examples());
}

