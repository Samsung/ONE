// clang-format off
// Generated file (from: argmax_float_2_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_float_2_nnfw {
// Generated argmax_float_2_nnfw test
#include "generated/examples/argmax_float_2_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/argmax_float_2_nnfw.model.cpp"
} // namespace argmax_float_2_nnfw

TEST_F(GeneratedTests, argmax_float_2_nnfw) {
    execute(argmax_float_2_nnfw::CreateModel,
            argmax_float_2_nnfw::is_ignored,
            argmax_float_2_nnfw::get_examples());
}

