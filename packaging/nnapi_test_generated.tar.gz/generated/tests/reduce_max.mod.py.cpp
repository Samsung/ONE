// clang-format off
// Generated file (from: reduce_max.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace reduce_max {
// Generated reduce_max test
#include "generated/examples/reduce_max.example.cpp"
// Generated model constructor
#include "generated/models/reduce_max.model.cpp"
} // namespace reduce_max

TEST_F(GeneratedTests, reduce_max) {
    execute(reduce_max::CreateModel,
            reduce_max::is_ignored,
            reduce_max::get_examples());
}

TEST_F(GeneratedTests, reduce_max_quant8) {
    execute(reduce_max::CreateModel_quant8,
            reduce_max::is_ignored_quant8,
            reduce_max::get_examples_quant8());
}

TEST_F(GeneratedTests, reduce_max_2) {
    execute(reduce_max::CreateModel_2,
            reduce_max::is_ignored_2,
            reduce_max::get_examples_2());
}

TEST_F(GeneratedTests, reduce_max_quant8_2) {
    execute(reduce_max::CreateModel_quant8_2,
            reduce_max::is_ignored_quant8_2,
            reduce_max::get_examples_quant8_2());
}

TEST_F(GeneratedTests, reduce_max_3) {
    execute(reduce_max::CreateModel_3,
            reduce_max::is_ignored_3,
            reduce_max::get_examples_3());
}

TEST_F(GeneratedTests, reduce_max_quant8_3) {
    execute(reduce_max::CreateModel_quant8_3,
            reduce_max::is_ignored_quant8_3,
            reduce_max::get_examples_quant8_3());
}

TEST_F(GeneratedTests, reduce_max_4) {
    execute(reduce_max::CreateModel_4,
            reduce_max::is_ignored_4,
            reduce_max::get_examples_4());
}

TEST_F(GeneratedTests, reduce_max_quant8_4) {
    execute(reduce_max::CreateModel_quant8_4,
            reduce_max::is_ignored_quant8_4,
            reduce_max::get_examples_quant8_4());
}

