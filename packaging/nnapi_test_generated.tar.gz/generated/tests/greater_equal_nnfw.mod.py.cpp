// clang-format off
// Generated file (from: greater_equal_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace greater_equal_nnfw {
// Generated greater_equal_nnfw test
#include "generated/examples/greater_equal_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/greater_equal_nnfw.model.cpp"
} // namespace greater_equal_nnfw

TEST_F(GeneratedTests, greater_equal_nnfw) {
    execute(greater_equal_nnfw::CreateModel,
            greater_equal_nnfw::is_ignored,
            greater_equal_nnfw::get_examples());
}

