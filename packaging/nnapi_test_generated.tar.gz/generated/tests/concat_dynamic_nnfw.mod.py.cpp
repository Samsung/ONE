// clang-format off
// Generated file (from: concat_dynamic_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace concat_dynamic_nnfw {
// Generated concat_dynamic_nnfw test
#include "generated/examples/concat_dynamic_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/concat_dynamic_nnfw.model.cpp"
} // namespace concat_dynamic_nnfw

TEST_F(GeneratedTests, concat_dynamic_nnfw) {
    execute(concat_dynamic_nnfw::CreateModel,
            concat_dynamic_nnfw::is_ignored,
            concat_dynamic_nnfw::get_examples());
}

