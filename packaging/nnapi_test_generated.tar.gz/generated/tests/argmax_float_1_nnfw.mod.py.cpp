// clang-format off
// Generated file (from: argmax_float_1_nnfw.mod.py). Do not edit
#include "../../TestGenerated.h"

namespace argmax_float_1_nnfw {
// Generated argmax_float_1_nnfw test
#include "generated/examples/argmax_float_1_nnfw.example.cpp"
// Generated model constructor
#include "generated/models/argmax_float_1_nnfw.model.cpp"
} // namespace argmax_float_1_nnfw

TEST_F(GeneratedTests, argmax_float_1_nnfw) {
    execute(argmax_float_1_nnfw::CreateModel,
            argmax_float_1_nnfw::is_ignored,
            argmax_float_1_nnfw::get_examples());
}

