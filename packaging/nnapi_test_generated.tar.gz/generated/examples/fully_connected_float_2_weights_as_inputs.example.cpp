// clang-format off
// Generated file (from: fully_connected_float_2_weights_as_inputs.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}, {1, {1, 1}}, {2, {1}}},
  // int -> FLOAT32 map
  {{0, {2.0f, 32.0f, 16.0f}}, {1, {2.0f}}, {2, {4.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}},
  // int -> FLOAT32 map
  {{0, {8.0f, 68.0f, 36.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}, {1, {1, 1}}, {2, {1}}},
  // int -> FLOAT32 map
  {{0, {2.0f, 32.0f, 16.0f}}, {1, {4.0f}}, {2, {4.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}},
  // int -> FLOAT32 map
  {{0, {12.0f, 132.0f, 68.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}, {1, {1, 1}}, {2, {1}}},
  // int -> FLOAT32 map
  {{0, {2.0f, 32.0f, 16.0f}}, {1, {10.0f}}, {2, {4.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 1}}},
  // int -> FLOAT32 map
  {{0, {24.0f, 324.0f, 164.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

