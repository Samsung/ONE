// clang-format off
// Generated file (from: transpose_conv_ex_float_3.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {4}}, {1, {1, 2, 2, 1}}},
  // int -> FLOAT32 map
  .float32Operands = {{1, {1.0f, 2.0f, 3.0f, 4.0f}}},
  // int -> INT32 map
  .int32Operands = {{0, {1, 5, 5, 2}}},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {1, 5, 5, 2}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {1.0f, 2.0f, 3.0f, 4.0f, 7.0f, 10.0f, 6.0f, 8.0f, 10.0f, 12.0f, 7.0f, 8.0f, 9.0f, 10.0f, 25.0f, 28.0f, 18.0f, 20.0f, 22.0f, 24.0f, 16.0f, 20.0f, 24.0f, 28.0f, 62.0f, 72.0f, 42.0f, 48.0f, 54.0f, 60.0f, 21.0f, 24.0f, 27.0f, 30.0f, 61.0f, 68.0f, 36.0f, 40.0f, 44.0f, 48.0f, 39.0f, 42.0f, 45.0f, 48.0f, 103.0f, 110.0f, 60.0f, 64.0f, 68.0f, 72.0f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

