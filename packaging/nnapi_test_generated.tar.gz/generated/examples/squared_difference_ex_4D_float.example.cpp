// clang-format off
// Generated file (from: squared_difference_ex_4D_float.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 2, 2, 2}}, {1, {2, 2, 2, 2}}},
  // int -> FLOAT32 map
  {{0, {4.0f, 7.8f, 3.1432f, 28.987456f, 9.0f, 6.0f, 5.0f, 12.0f, 2.0f, 10.8f, 19.4212f, 10.0f, 27.0f, 36.0f, 64.0f, 128.0f}}, {1, {2.0f, 3.2f, 1.9856f, 8.167952f, 1.0f, 2.0f, 5.0f, 14.0f, 2.0f, 4.4f, 15.9856f, 6.0f, 18.0f, 30.0f, 61.0f, 120.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 2, 2, 2}}},
  // int -> FLOAT32 map
  {{0, {4.0f, 21.16f, 1.34003776f, 433.451746806016f, 64.0f, 16.0f, 0.0f, 4.0f, 0.0f, 40.96f, 11.80334736f, 16.0f, 81.0f, 36.0f, 9.0f, 64.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

