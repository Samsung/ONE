// clang-format off
// Generated file (from: div_broadcast_float_4D_2D_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 2, 2, 2}}, {1, {2, 2}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {16.0f, 11.0f, 23.0f, 3.0f, 9.0f, 14.0f, 9.0f, 2.0f, 0.0f, 23.0f, 13.0f, 2.0f, 13.0f, 17.0f, 16.0f, 10.0f, 15.0f, 19.0f, 12.0f, 16.0f, 15.0f, 20.0f, 9.0f, 7.0f}}, {1, {16.0f, 7.0f, 23.0f, 16.0f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 2, 2, 2}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {1.0f, 1.57142857f, 1.0f, 0.1875f, 0.5625f, 2.0f, 0.39130435f, 0.125f, 0.0f, 3.28571429f, 0.56521739f, 0.125f, 0.8125f, 2.42857143f, 0.69565217f, 0.625f, 0.9375f, 2.71428571f, 0.52173913f, 1.0f, 0.9375f, 2.85714286f, 0.39130435f, 0.4375f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

