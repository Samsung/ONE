// clang-format off
// Generated file (from: mobilenet_224_gender_basic_fixed.mod.py). Do not edit
