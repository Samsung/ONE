// clang-format off
// Generated file (from: exp_ex_4D_float.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 3, 2, 3}}},
  // int -> FLOAT32 map
  {{0, {3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f, 7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 2.123456789123457f, 18.123456789123455f, 19.123456789123455f, 11.123456789123457f, 7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f, 3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f, 2.123456789123457f, 18.123456789123455f, 19.123456789123455f, 11.123456789123457f, 7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 2.123456789123457f, 18.123456789123455f, 19.123456789123455f, 11.123456789123457f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 3, 2, 3}}},
  // int -> FLOAT32 map
  {{0, {22.724796f, 61.772419f, 167.91484f, 456.43985f, 1240.7322f, 3372.6597f, 9167.8398f, 3.0754671f, 8.3599854f, 74287776.0f, 201935100.0f, 67741.68f, 1240.7322f, 3372.6597f, 9167.8398f, 3.0754671f, 22.724796f, 61.772419f, 167.91484f, 456.43985f, 22.724796f, 61.772419f, 167.91484f, 456.43985f, 8.3599854f, 74287776.0f, 201935100.0f, 67741.68f, 1240.7322f, 3372.6597f, 9167.8398f, 3.0754671f, 8.3599854f, 74287776.0f, 201935100.0f, 67741.68f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

