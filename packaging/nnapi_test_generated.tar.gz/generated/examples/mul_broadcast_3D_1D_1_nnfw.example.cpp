// clang-format off
// Generated file (from: mul_broadcast_3D_1D_1_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 1, 4}}, {1, {4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.8364028931f, 0.6620308161f, 1.1811592579f, 0.4827561378f, -0.384627074f, -1.7236120701f, 3.5318591595f, 0.2959995866f, 1.6260499954f, -0.7885181308f, -0.8246002197f, -1.1367146969f}}, {1, {0.8364028931f, -0.384627074f, 1.6260499954f, 0.6620308161f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 1, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.6995698214f, -0.2546349764f, 1.9206240177f, 0.3195994496f, -0.3217031956f, 0.6629478931f, 5.7429795265f, 0.1959608495f, 1.3600329161f, 0.3032854199f, -1.3408411741f, -0.7525401711f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

