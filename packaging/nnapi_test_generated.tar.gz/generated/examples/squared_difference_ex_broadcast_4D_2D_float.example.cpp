// clang-format off
// Generated file (from: squared_difference_ex_broadcast_4D_2D_float.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 2, 2, 2}}, {1, {2, 2}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {74.0f, 63.0f, 103.0f, 88.0f, 57.0f, 9.0f, 68.0f, 20.0f, 121.0f, 38.0f, 54.0f, 119.0f, 56.0f, 106.0f, 98.0f, 98.0f, 7.0f, 89.0f, 108.0f, 104.0f, 20.0f, 81.0f, 4.0f, 124.0f}}, {1, {56.0f, 115.0f, 115.0f, 116.0f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 2, 2, 2}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {324.0f, 2704.0f, 144.0f, 784.0f, 1.0f, 11236.0f, 2209.0f, 9216.0f, 4225.0f, 5929.0f, 3721.0f, 9.0f, 0.0f, 81.0f, 289.0f, 324.0f, 2401.0f, 676.0f, 49.0f, 144.0f, 1296.0f, 1156.0f, 12321.0f, 64.0f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

