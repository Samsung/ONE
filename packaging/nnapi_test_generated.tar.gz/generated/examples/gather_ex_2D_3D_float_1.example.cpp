// clang-format off
// Generated file (from: gather_ex_2D_3D_float_1.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 4}}, {1, {1, 1, 2}}},
  // int -> FLOAT32 map
  {{0, {3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f, 7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 2.123456789123457f, 18.123456789123455f, 19.123456789123455f, 11.123456789123457f}}},
  // int -> INT32 map
  {{1, {1, 0}}},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {1, 1, 2, 4}}},
  // int -> FLOAT32 map
  {{0, {7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

