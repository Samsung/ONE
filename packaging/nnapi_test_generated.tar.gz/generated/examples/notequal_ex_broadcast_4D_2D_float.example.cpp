// clang-format off
// Generated file (from: notequal_ex_broadcast_4D_2D_float.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 2, 2}}, {1, {2, 2}}},
  // int -> FLOAT32 map
  {{0, {4.25f, 11.0f, 2.2f, 10.3f, 8.5f, 2.1f, 1.0f, 0.5f, 3.1f, 1.0f, 8.5f, 6.5f, 11.2f, 3.0f, 8.5f, 1.0f, 0.3f, 3.0f, 2.1f, 7.5f, 4.3f, 9.2f, 11.1f, 3.0f}}, {1, {8.5f, 3.0f, 2.1f, 10.3f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 2, 2}}},
  // int -> FLOAT32 map
  {},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {{0, {255, 255, 255, 0, 0, 255, 255, 255, 255, 255, 255, 255, 255, 0, 255, 255, 255, 0, 0, 255, 255, 255, 255, 255}}},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

