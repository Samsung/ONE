// clang-format off
// Generated file (from: concat_float_4D_axis3_1_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {1, 2, 3, 2}}, {1, {1, 2, 3, 2}}, {2, {1, 2, 3, 2}}},
  // int -> FLOAT32 map
  {{0, {-0.03203143f, -0.0334147f, -0.02527265f, 0.04576106f, 0.08869292f, 0.06428383f, -0.06473722f, -0.21933985f, -0.05541003f, -0.24157837f, -0.16328812f, -0.04581105f}}, {1, {-0.0569439f, -0.15872048f, 0.02965238f, -0.12761882f, -0.00185435f, -0.03297619f, 0.03581043f, -0.12603407f, 0.05999133f, 0.00290503f, 0.1727029f, 0.03342071f}}, {2, {0.10992613f, 0.09185287f, 0.16433905f, -0.00059073f, -0.01480746f, 0.0135175f, 0.07129054f, -0.15095694f, -0.04579685f, -0.13260484f, -0.10045543f, 0.0647094f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {1, 2, 3, 6}}},
  // int -> FLOAT32 map
  {{0, {-0.03203143f, -0.0334147f, -0.0569439f, -0.15872048f, 0.10992613f, 0.09185287f, -0.02527265f, 0.04576106f, 0.02965238f, -0.12761882f, 0.16433905f, -0.00059073f, 0.08869292f, 0.06428383f, -0.00185435f, -0.03297619f, -0.01480746f, 0.0135175f, -0.06473722f, -0.21933985f, 0.03581043f, -0.12603407f, 0.07129054f, -0.15095694f, -0.05541003f, -0.24157837f, 0.05999133f, 0.00290503f, -0.04579685f, -0.13260484f, -0.16328812f, -0.04581105f, 0.1727029f, 0.03342071f, -0.10045543f, 0.0647094f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

