// clang-format off
// Generated file (from: sub_broadcast_4D_2D_float_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 2, 2}}, {1, {2, 2}}},
  // int -> FLOAT32 map
  {{0, {0.02648412f, 0.12737854f, 0.92319058f, 0.60023185f, 0.35821535f, 0.96402954f, 0.64612486f, 0.71984435f, 0.59125833f, 0.18123407f, 0.47523563f, 0.35624883f, 0.67594663f, 0.69254679f, 0.63816926f, 0.82754998f, 0.4535841f, 0.66132381f, 0.40122975f, 0.02461688f, 0.58031493f, 0.44518958f, 0.26908303f, 0.82039221f}}, {1, {0.52241209f, 0.02719438f, 0.071708f, 0.6779468f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 2, 2}}},
  // int -> FLOAT32 map
  {{0, {-0.49592797f, 0.10018416f, 0.85148259f, -0.07771495f, -0.16419674f, 0.93683516f, 0.57441687f, 0.04189755f, 0.06884624f, 0.15403969f, 0.40352763f, -0.32169797f, 0.15353454f, 0.66535241f, 0.56646126f, 0.14960318f, -0.06882799f, 0.63412943f, 0.32952176f, -0.65332992f, 0.05790284f, 0.4179952f, 0.19737503f, 0.14244541f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

