// clang-format off
// Generated file (from: space_to_batch_quant8_1.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {1, 4, 4, 1}}},
  // int -> FLOAT32 map
  {},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {{0, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}}},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {4, 2, 2, 1}}},
  // int -> FLOAT32 map
  {},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {{0, {1, 3, 9, 11, 2, 4, 10, 12, 5, 7, 13, 15, 6, 8, 14, 16}}},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

