// clang-format off
// Generated file (from: sqrt_ex_4D_float.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 2, 2, 2}}},
  // int -> FLOAT32 map
  {{0, {36.0f, 90.0f, 43.0f, 36.0f, 2.0f, 22.0f, 19.0f, 10.0f, 9.0f, 80.0f, 40.0f, 90.0f, 15.0f, 56.0f, 18.0f, 12.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {2, 2, 2, 2}}},
  // int -> FLOAT32 map
  {{0, {6.0f, 9.48683298f, 6.55743852f, 6.0f, 1.41421356f, 4.69041576f, 4.35889894f, 3.16227766f, 3.0f, 8.94427191f, 6.32455532f, 9.48683298f, 3.87298335f, 7.48331477f, 4.24264069f, 3.46410162f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

