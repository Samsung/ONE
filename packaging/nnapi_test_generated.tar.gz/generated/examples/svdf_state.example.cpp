// clang-format off
// Generated file (from: svdf_state.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {2, 3}}, {1, {4, 3}}, {2, {4, 10}}, {3, {4}}, {4, {2, 40}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.14278367f, -1.64410412f, -0.75222826f, 0.14278367f, -1.64410412f, -0.75222826f}}, {1, {-0.31930989f, -0.36118156f, 0.0079667f, 0.37613347f, 0.22197971f, 0.12416199f, 0.27901134f, 0.27557442f, 0.3905206f, -0.36137494f, -0.06634006f, -0.10640851f}}, {2, {-0.31930989f, 0.37613347f, 0.27901134f, -0.36137494f, -0.36118156f, 0.22197971f, 0.27557442f, -0.06634006f, 0.0079667f, 0.12416199f, 0.3905206f, -0.10640851f, -0.0976817f, 0.15294972f, 0.39635518f, -0.02702999f, 0.39296314f, 0.15785322f, 0.21931258f, 0.31053296f, -0.36916667f, 0.38031587f, -0.21580373f, 0.27072677f, 0.23622236f, 0.34936687f, 0.18174365f, 0.35907319f, -0.17493086f, 0.324846f, -0.10781813f, 0.27201805f, 0.14324132f, -0.23681851f, -0.27115166f, -0.01580888f, -0.14943552f, 0.15465137f, 0.09784451f, -0.0337657f}}, {3, {}}, {4, {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.119996f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.166701f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.44244f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0805206f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.119996f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.166701f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.44244f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0805206f, 0.0f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {2, 40}}, {1, {2, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.119996f, 0.542235f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.166701f, -0.40465f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.44244f, -0.706995f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0805206f, 0.137515f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.119996f, 0.542235f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.166701f, -0.40465f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -0.44244f, -0.706995f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0805206f, 0.137515f, 0.0f}}, {1, {0.068281f, -0.162217f, -0.152268f, 0.00323521f, 0.068281f, -0.162217f, -0.152268f, 0.00323521f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

