// clang-format off
// Generated file (from: pack_ex_dynamic_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {6, 4}}, {1, {2}}, {2, {6, 4}}, {3, {6, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.3f, 1.0f, 2.0f, 3.0f, 4.0f, 5.5f, 6.3f, 7.2f, 8.22f, 9.8f, 10.3f, 11.0f, 12.22f, 13.2f, 14.44f, 15.32f, 16.55f, 17.33f, 18.1f, 19.0f, 20.32f, 21.9f, 22.1f, 23.22f}}, {2, {24.22f, 25.1f, 26.0f, 27.12f, 28.32f, 29.11f, 30.0f, 31.98f, 32.99f, 33.11f, 34.1f, 35.123f, 36.21f, 37.22f, 38.23f, 39.76f, 40.1f, 41.43f, 42.34f, 43.1f, 44.123f, 45.43f, 46.1f, 47.1f}}, {3, {48.0f, 49.76f, 50.0f, 51.1f, 52.22f, 53.12f, 54.1f, 55.5f, 56.5f, 57.4f, 58.1f, 59.23f, 60.2f, 61.12f, 62.11f, 63.34f, 64.11f, 65.1f, 66.43f, 67.1f, 68.1f, 69.34f, 70.11f, 71.45f}}},
  // int -> INT32 map
  .int32Operands = {{1, {6, 4}}},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {6, 3, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.3f, 1.0f, 2.0f, 3.0f, 24.22f, 25.1f, 26.0f, 27.12f, 48.0f, 49.76f, 50.0f, 51.1f, 4.0f, 5.5f, 6.3f, 7.2f, 28.32f, 29.11f, 30.0f, 31.98f, 52.22f, 53.12f, 54.1f, 55.5f, 8.22f, 9.8f, 10.3f, 11.0f, 32.99f, 33.11f, 34.1f, 35.123f, 56.5f, 57.4f, 58.1f, 59.23f, 12.22f, 13.2f, 14.44f, 15.32f, 36.21f, 37.22f, 38.23f, 39.76f, 60.2f, 61.12f, 62.11f, 63.34f, 16.55f, 17.33f, 18.1f, 19.0f, 40.1f, 41.43f, 42.34f, 43.1f, 64.11f, 65.1f, 66.43f, 67.1f, 20.32f, 21.9f, 22.1f, 23.22f, 44.123f, 45.43f, 46.1f, 47.1f, 68.1f, 69.34f, 70.11f, 71.45f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

