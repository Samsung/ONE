// clang-format off
// Generated file (from: mul_broadcast_3D_1D_2_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 4}}, {1, {4}}},
  // int -> FLOAT32 map
  {{0, {2.2774236202f, -2.4773113728f, -0.4044751823f, -0.8101355433f, -1.9691983461f, 2.2676842213f, -2.2757787704f, -0.8289190531f, 0.0121828541f, -1.7484937906f, -0.5269883871f, -0.6346995831f, 2.4886128902f, -1.5107979774f, -0.7372134924f, -0.5374289751f, -1.2039715052f, 1.527836442f, 0.8248311877f, -2.4172706604f, 0.6997106671f, -0.8929677606f, 0.3650484681f, 1.3652951717f}}, {1, {2.2774236202f, 0.0121828541f, -1.2039715052f, -1.9691983461f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {3, 2, 4}}},
  // int -> FLOAT32 map
  {{0, {5.1866583824f, -0.0301807225f, 0.4869765937f, 1.5953176022f, -4.4846987724f, 0.0276268665f, 2.7399728298f, 1.6323059797f, 0.0277455188f, -0.0213016439f, 0.6344789863f, 1.2498493195f, 5.6676259041f, -0.0184058305f, 0.8875840306f, 1.0583041906f, -2.7419531345f, 0.0186134093f, -0.993073225f, 4.7600855827f, 1.593537569f, -0.0108788963f, -0.4395079613f, -2.6885368824f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

