// clang-format off
// Generated file (from: pack_ex_2D_int_2.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {6, 4}}, {1, {6, 4}}, {2, {6, 4}}},
  // int -> FLOAT32 map
  {},
  // int -> INT32 map
  {{0, {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23}}, {1, {24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47}}, {2, {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71}}},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {6, 3, 4}}},
  // int -> FLOAT32 map
  {},
  // int -> INT32 map
  {{0, {0, 1, 2, 3, 24, 25, 26, 27, 48, 49, 50, 51, 4, 5, 6, 7, 28, 29, 30, 31, 52, 53, 54, 55, 8, 9, 10, 11, 32, 33, 34, 35, 56, 57, 58, 59, 12, 13, 14, 15, 36, 37, 38, 39, 60, 61, 62, 63, 16, 17, 18, 19, 40, 41, 42, 43, 64, 65, 66, 67, 20, 21, 22, 23, 44, 45, 46, 47, 68, 69, 70, 71}}},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

