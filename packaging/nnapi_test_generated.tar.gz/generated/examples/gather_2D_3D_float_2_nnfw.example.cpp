// clang-format off
// Generated file (from: gather_2D_3D_float_2_nnfw.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 4}}, {1, {1, 2, 1}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {3.123456789123457f, 4.123456789123456f, 5.123456789123456f, 6.123456789123456f, 7.123456789123456f, 8.123456789123457f, 9.123456789123457f, 1.1234567891234568f, 2.123456789123457f, 18.123456789123455f, 19.123456789123455f, 11.123456789123457f}}},
  // int -> INT32 map
  .int32Operands = {{1, {1, 0}}},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {3, 1, 2, 1}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {4.123456789123456f, 3.123456789123457f, 8.123456789123457f, 7.123456789123456f, 18.123456789123455f, 2.123456789123457f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

