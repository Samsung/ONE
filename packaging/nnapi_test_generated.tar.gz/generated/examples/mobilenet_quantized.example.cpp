// clang-format off
// Generated file (from: mobilenet_quantized.mod.py). Do not edit
