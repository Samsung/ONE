// clang-format off
// Generated file (from: transpose_conv_ex_float_2.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
 {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {4}}, {1, {1, 2, 2, 1}}},
  // int -> FLOAT32 map
  {{1, {1.0f, 2.0f, 3.0f, 4.0f}}},
  // int -> INT32 map
  {{0, {1, 5, 5, 1}}},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  {{0, {1, 5, 5, 1}}},
  // int -> FLOAT32 map
  {{0, {1.0f, 2.0f, 5.0f, 4.0f, 6.0f, 4.0f, 5.0f, 14.0f, 10.0f, 12.0f, 10.0f, 14.0f, 36.0f, 24.0f, 30.0f, 12.0f, 15.0f, 34.0f, 20.0f, 24.0f, 21.0f, 24.0f, 55.0f, 32.0f, 36.0f}}},
  // int -> INT32 map
  {},
  // int -> QUANT8_ASYMM map
  {},
  // int -> QUANT16_SYMM map
  {},
  // int -> FLOAT16 map
  //{},
  // int -> BOOL8 map
  {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  {},
  // int -> QUANT16_ASYMM map
  {},
  // int -> QUANT8_SYMM map
  {},
}
},
0.0
}, // End of an example
};
return examples;
};

