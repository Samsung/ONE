// clang-format off
// Generated file (from: unpack_ex_3D_float_2.mod.py). Do not edit
std::vector<MixedTypedExample>& get_examples() {
static std::vector<MixedTypedExample> examples = {
// Begin of an example
{
.operands = {
//Input(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {6, 3, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.3f, 1.2f, 2.1f, 3.454f, 4.12f, 5.23f, 6.34f, 7.12f, 8.2f, 9.23f, 10.11f, 11.34f, 12.3f, 13.12f, 14.122f, 15.1f, 16.11f, 17.234f, 18.2f, 19.1f, 20.45f, 21.5f, 22.5f, 23.64f, 24.2f, 25.76f, 26.4f, 27.34f, 28.43f, 29.112f, 30.45f, 31.5f, 32.45f, 33.65f, 34.6f, 35.34f, 36.3f, 37.54f, 38.6743f, 39.56f, 40.451f, 41.56f, 42.55f, 43.511f, 44.4f, 45.45f, 46.5641f, 47.122f, 48.1f, 49.456f, 50.56f, 51.11f, 52.1f, 53.34f, 54.62f, 55.1f, 56.12f, 57.4f, 58.2f, 59.1f, 60.465f, 61.1f, 62.3f, 63.45f, 64.1f, 65.11f, 66.4f, 67.9f, 68.123f, 69.65f, 70.89f, 71.987f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
},
//Output(s)
{ // See tools/test_generator/include/TestHarness.h:MixedTyped
  // int -> Dimensions map
  .operandDimensions = {{0, {6, 4}}, {1, {6, 4}}, {2, {6, 4}}},
  // int -> FLOAT32 map
  .float32Operands = {{0, {0.3f, 1.2f, 2.1f, 3.454f, 12.3f, 13.12f, 14.122f, 15.1f, 24.2f, 25.76f, 26.4f, 27.34f, 36.3f, 37.54f, 38.6743f, 39.56f, 48.1f, 49.456f, 50.56f, 51.11f, 60.465f, 61.1f, 62.3f, 63.45f}}, {1, {4.12f, 5.23f, 6.34f, 7.12f, 16.11f, 17.234f, 18.2f, 19.1f, 28.43f, 29.112f, 30.45f, 31.5f, 40.451f, 41.56f, 42.55f, 43.511f, 52.1f, 53.34f, 54.62f, 55.1f, 64.1f, 65.11f, 66.4f, 67.9f}}, {2, {8.2f, 9.23f, 10.11f, 11.34f, 20.45f, 21.5f, 22.5f, 23.64f, 32.45f, 33.65f, 34.6f, 35.34f, 44.4f, 45.45f, 46.5641f, 47.122f, 56.12f, 57.4f, 58.2f, 59.1f, 68.123f, 69.65f, 70.89f, 71.987f}}},
  // int -> INT32 map
  .int32Operands = {},
  // int -> QUANT8_ASYMM map
  .quant8AsymmOperands = {},
  // int -> QUANT16_SYMM map
  .quant16SymmOperands = {},
  // int -> FLOAT16 map
  .float16Operands = {},
  // int -> BOOL8 map
  .bool8Operands = {},
  // int -> QUANT8_SYMM_PER_CHANNEL map
  .quant8ChannelOperands = {},
  // int -> QUANT16_ASYMM map
  .quant16AsymmOperands = {},
  // int -> QUANT8_SYMM map
  .quant8SymmOperands = {},
}
},
}, // End of an example
};
return examples;
};

