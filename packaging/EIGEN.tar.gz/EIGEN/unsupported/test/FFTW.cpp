#define EIGEN_FFTW_DEFAULT 1
#include "fft_test_shared.h"
