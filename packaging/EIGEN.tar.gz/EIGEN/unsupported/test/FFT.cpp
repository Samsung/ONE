#define EIGEN_FFT_DEFAULT 1
#include "fft_test_shared.h"
