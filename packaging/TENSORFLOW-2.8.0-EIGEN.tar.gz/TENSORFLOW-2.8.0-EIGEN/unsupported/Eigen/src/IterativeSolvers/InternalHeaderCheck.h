#ifndef EIGEN_ITERATIVE_SOLVERS_MODULE_H
#error "Please include unsupported/Eigen/IterativeSolvers instead of including headers inside the src directory directly."
#endif
