#ifndef EIGEN_KRONECKER_PRODUCT_MODULE_H
#error "Please include unsupported/Eigen/KroneckerProduct instead of including headers inside the src directory directly."
#endif
